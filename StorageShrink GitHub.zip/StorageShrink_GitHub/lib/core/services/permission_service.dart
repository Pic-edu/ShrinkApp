import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';

enum PermissionResult { granted, denied, permanentlyDenied }

class PermissionService {
  static final PermissionService _instance = PermissionService._internal();
  factory PermissionService() => _instance;
  PermissionService._internal();

  Future<PermissionResult> requestStoragePermission() async {
    if (Platform.isAndroid) return _requestAndroidPermissions();
    if (Platform.isIOS)     return _requestIOSPermissions();
    return PermissionResult.denied;
  }

  Future<PermissionResult> _requestAndroidPermissions() async {
    final deviceInfo = DeviceInfoPlugin();
    final android    = await deviceInfo.androidInfo;
    final sdkInt     = android.version.sdkInt;

    if (sdkInt >= 33) {
      final results = await [
        Permission.photos,
        Permission.videos,
        Permission.audio,
      ].request();
      final allGranted =
          results.values.every((s) => s == PermissionStatus.granted);
      if (allGranted) return PermissionResult.granted;
      final anyPermanent =
          results.values.any((s) => s == PermissionStatus.permanentlyDenied);
      return anyPermanent
          ? PermissionResult.permanentlyDenied
          : PermissionResult.denied;
    }

    if (sdkInt >= 30) {
      final status = await Permission.manageExternalStorage.request();
      return _mapStatus(status);
    }

    final results = await [Permission.storage].request();
    return _mapStatus(results[Permission.storage]!);
  }

  Future<PermissionResult> _requestIOSPermissions() async {
    final status = await Permission.photos.request();
    return _mapStatus(status);
  }

  PermissionResult _mapStatus(PermissionStatus status) {
    switch (status) {
      case PermissionStatus.granted:
      case PermissionStatus.limited:
        return PermissionResult.granted;
      case PermissionStatus.permanentlyDenied:
        return PermissionResult.permanentlyDenied;
      default:
        return PermissionResult.denied;
    }
  }

  Future<bool> hasStoragePermission() async {
    if (Platform.isAndroid) {
      final deviceInfo = DeviceInfoPlugin();
      final android    = await deviceInfo.androidInfo;
      if (android.version.sdkInt >= 33) {
        return (await Permission.photos.status).isGranted;
      }
      if (android.version.sdkInt >= 30) {
        return (await Permission.manageExternalStorage.status).isGranted;
      }
      return (await Permission.storage.status).isGranted;
    }
    if (Platform.isIOS) {
      final s = await Permission.photos.status;
      return s.isGranted || s.isLimited;
    }
    return false;
  }

  Future<void> openSettings() => openAppSettings();
}
