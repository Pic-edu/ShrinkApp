import 'dart:convert';
import 'dart:io';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import '../../data/models/file_item.dart';
import '../../data/models/trash_item.dart';

class TrashManagerService {
  static final TrashManagerService _i = TrashManagerService._();
  factory TrashManagerService() => _i;
  TrashManagerService._();

  static const _boxName = 'smart_trash';
  static const _uuid    = Uuid();

  Future<Box<String>> _box() => Hive.openBox<String>(_boxName);

  Future<TrashItem> moveToTrash(FileItem file) async {
    final item    = TrashItem.fromFileItem(file);
    final box     = await _box();
    final trashDir= await _trashDirectory();
    final dest    = p.join(trashDir.path, '${item.id}_${item.name}');
    try { await File(file.path).copy(dest); } catch (_) {}
    await box.put(item.id, jsonEncode(item.toMap()));
    return item;
  }

  Future<List<TrashItem>> moveMultipleToTrash(List<FileItem> files) async {
    final results = <TrashItem>[];
    for (final f in files) results.add(await moveToTrash(f));
    return results;
  }

  Future<bool> restore(String itemId) async {
    final box  = await _box();
    final json = box.get(itemId);
    if (json == null) return false;
    final item = TrashItem.fromMap(jsonDecode(json) as Map<String, dynamic>);
    final tp   = await _trashPathFor(item);
    try {
      if (await File(tp).exists()) await File(tp).copy(item.originalPath);
      await box.delete(itemId);
      return true;
    } catch (_) { return false; }
  }

  Future<void> permanentlyDelete(String itemId) async {
    final box  = await _box();
    final json = box.get(itemId);
    if (json == null) return;
    final item = TrashItem.fromMap(jsonDecode(json) as Map<String, dynamic>);
    final tp   = await _trashPathFor(item);
    try { await File(tp).delete(); } catch (_) {}
    try { await File(item.originalPath).delete(); } catch (_) {}
    await box.delete(itemId);
  }

  Future<int> purgeExpired() async {
    final box  = await _box();
    int purged = 0;
    for (final key in box.keys.toList()) {
      final json = box.get(key.toString());
      if (json == null) continue;
      final item = TrashItem.fromMap(jsonDecode(json) as Map<String, dynamic>);
      if (item.state == TrashItemState.expired) {
        await permanentlyDelete(item.id);
        purged++;
      }
    }
    return purged;
  }

  Future<List<TrashItem>> getAll() async {
    final box   = await _box();
    final items = <TrashItem>[];
    for (final key in box.keys) {
      final json = box.get(key.toString());
      if (json != null) {
        try {
          items.add(TrashItem.fromMap(jsonDecode(json) as Map<String, dynamic>));
        } catch (_) {}
      }
    }
    items.sort((a, b) {
      if (a.state == TrashItemState.expired &&
          b.state != TrashItemState.expired) return -1;
      if (b.state == TrashItemState.expired &&
          a.state != TrashItemState.expired) return 1;
      return a.expiresAt.compareTo(b.expiresAt);
    });
    return items;
  }

  Future<int> emptyTrash() async {
    final all = await getAll();
    for (final item in all) await permanentlyDelete(item.id);
    return all.length;
  }

  Future<int> totalSizeBytes() async {
    final all = await getAll();
    return all.fold(0, (s, i) => s + i.sizeBytes);
  }

  Future<Directory> _trashDirectory() async {
    final base = await getApplicationDocumentsDirectory();
    final dir  = Directory(p.join(base.path, 'StorageShrink', 'Trash'));
    await dir.create(recursive: true);
    return dir;
  }

  Future<String> _trashPathFor(TrashItem item) async {
    final dir = await _trashDirectory();
    return p.join(dir.path, '${item.id}_${item.name}');
  }
}
