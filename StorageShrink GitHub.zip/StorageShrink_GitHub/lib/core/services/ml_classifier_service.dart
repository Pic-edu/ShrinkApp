import 'dart:async';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';
import 'package:google_mlkit_barcode_scanning/google_mlkit_barcode_scanning.dart';

import '../../data/models/file_item.dart';
import '../../data/models/screenshot_category.dart';

class MLClassifierService {
  static final MLClassifierService _instance =
      MLClassifierService._internal();
  factory MLClassifierService() => _instance;
  MLClassifierService._internal();

  TextRecognizer? _textRecognizer;
  ImageLabeler?   _imageLabeler;
  BarcodeScanner? _barcodeScanner;

  void _initIfNeeded() {
    _textRecognizer ??= TextRecognizer(script: TextRecognitionScript.latin);
    _imageLabeler   ??= ImageLabeler(
        options: ImageLabelerOptions(confidenceThreshold: 0.55));
    _barcodeScanner ??= BarcodeScanner(
        formats: [BarcodeFormat.qrCode, BarcodeFormat.all]);
  }

  Stream<ClassificationBatch> classifyBatch(List<FileItem> files) async* {
    _initIfNeeded();
    final results = <ClassificationResult>[];
    final total   = files.length;

    for (int i = 0; i < total; i++) {
      final file = files[i];
      try {
        results.add(await _classifyOne(file));
      } catch (_) {
        results.add(ClassificationResult(
          fileId: file.id, filePath: file.path,
          category: ScreenshotCategory.uncategorized,
          confidence: 0.0,
        ));
      }
      yield ClassificationBatch(
        results: List.from(results),
        isComplete: i == total - 1,
        progressPercent: (i + 1) / total,
      );
    }
  }

  Future<ClassificationResult> _classifyOne(FileItem file) async {
    final inputImage = InputImage.fromFilePath(file.path);
    final futures    = await Future.wait([
      _runOCR(inputImage),
      _runLabeling(inputImage),
      _runBarcode(inputImage),
    ]);

    final ocrResult     = futures[0] as _OcrResult;
    final labelResult   = futures[1] as _LabelResult;
    final barcodeResult = futures[2] as _BarcodeResult;

    final scores  = _ScoreAggregator.aggregate(
      ocrResult: ocrResult,
      labelResult: labelResult,
      barcodeResult: barcodeResult,
    );
    final topEntry = scores.entries.reduce((a, b) => a.value >= b.value ? a : b);

    return ClassificationResult(
      fileId: file.id, filePath: file.path,
      category: topEntry.key,
      confidence: topEntry.value,
      detectedLabels: labelResult.labels,
      extractedText: ocrResult.fullText.length > 200
          ? ocrResult.fullText.substring(0, 200)
          : ocrResult.fullText,
      hasQrCode: barcodeResult.hasQr,
      qrData: barcodeResult.rawValue,
      suggestedContact: _extractContactName(ocrResult, topEntry.key),
    );
  }

  Future<_OcrResult> _runOCR(InputImage image) async {
    try {
      final recognized = await _textRecognizer!.processImage(image);
      final blocks     = recognized.blocks;
      final fullText   = blocks.map((b) => b.text).join(' ');
      return _OcrResult(
        fullText: fullText,
        blockCount: blocks.length,
        hasChatBubbles: _detectChatBubbles(blocks),
        hasSubtitles: _detectSubtitles(blocks),
        hasUrl: fullText.contains('http') ||
            fullText.contains('www.') ||
            RegExp(r'\.(com|net|org|io|co)\b').hasMatch(fullText),
        hasLongArticleText: fullText.split(' ').length > 80,
        hasReceiptKeywords: _detectReceiptKeywords(fullText),
        hasVideoProgress: _detectVideoProgress(blocks),
        blocks: blocks,
      );
    } catch (_) {
      return const _OcrResult(fullText: '', blockCount: 0);
    }
  }

  Future<_LabelResult> _runLabeling(InputImage image) async {
    try {
      final labels = await _imageLabeler!.processImage(image);
      return _LabelResult(
        labels: labels.map((l) => l.label.toLowerCase()).toList(),
        scores: {for (final l in labels) l.label.toLowerCase(): l.confidence},
      );
    } catch (_) {
      return const _LabelResult(labels: [], scores: {});
    }
  }

  Future<_BarcodeResult> _runBarcode(InputImage image) async {
    try {
      final barcodes = await _barcodeScanner!.processImage(image);
      if (barcodes.isEmpty) return const _BarcodeResult(hasQr: false);
      return _BarcodeResult(
          hasQr: true,
          rawValue: barcodes.first.rawValue,
          barcodeType: barcodes.first.type);
    } catch (_) {
      return const _BarcodeResult(hasQr: false);
    }
  }

  bool _detectChatBubbles(List<TextBlock> blocks) {
    if (blocks.length < 4) return false;
    final xs   = blocks.map((b) => b.boundingBox.left).toList();
    final minX = xs.reduce((a, b) => a < b ? a : b);
    final maxX = xs.reduce((a, b) => a > b ? a : b);
    return (maxX - minX) > 180 && blocks.length >= 5;
  }

  bool _detectSubtitles(List<TextBlock> blocks) {
    if (blocks.isEmpty || blocks.length > 4) return false;
    for (final block in blocks) {
      if (block.boundingBox.left > 160 && block.boundingBox.right < 920) {
        return true;
      }
    }
    return false;
  }

  bool _detectReceiptKeywords(String text) {
    final lower    = text.toLowerCase();
    final keywords = [
      'total', 'amount', 'payment', 'receipt', 'invoice', 'tax',
      'المجموع', 'الإجمالي', 'فاتورة', 'إيصال', 'ضريبة',
      'booking', 'confirmation', 'order', 'flight', 'gate',
      'رحلة', 'حجز', 'تأكيد',
    ];
    return keywords.any((k) => lower.contains(k));
  }

  bool _detectVideoProgress(List<TextBlock> blocks) {
    final pattern = RegExp(r'\d{1,2}:\d{2}');
    return blocks.any((b) => pattern.hasMatch(b.text));
  }

  String? _extractContactName(_OcrResult ocr, ScreenshotCategory cat) {
    if (cat != ScreenshotCategory.chat || ocr.blocks.isEmpty) return null;
    final sorted = [...ocr.blocks]
      ..sort((a, b) => a.boundingBox.top.compareTo(b.boundingBox.top));
    final firstLine = sorted.first.lines.isNotEmpty
        ? sorted.first.lines.first.text.trim()
        : null;
    if (firstLine != null &&
        firstLine.length > 1 &&
        firstLine.length < 40) return firstLine;
    return null;
  }

  Future<void> dispose() async {
    await _textRecognizer?.close();
    await _imageLabeler?.close();
    await _barcodeScanner?.close();
    _textRecognizer = null;
    _imageLabeler   = null;
    _barcodeScanner = null;
  }
}

class _OcrResult {
  final String fullText;
  final int blockCount;
  final bool hasChatBubbles;
  final bool hasSubtitles;
  final bool hasUrl;
  final bool hasLongArticleText;
  final bool hasReceiptKeywords;
  final bool hasVideoProgress;
  final List<TextBlock> blocks;

  const _OcrResult({
    required this.fullText,
    required this.blockCount,
    this.hasChatBubbles = false,
    this.hasSubtitles = false,
    this.hasUrl = false,
    this.hasLongArticleText = false,
    this.hasReceiptKeywords = false,
    this.hasVideoProgress = false,
    this.blocks = const [],
  });
}

class _LabelResult {
  final List<String> labels;
  final Map<String, double> scores;
  const _LabelResult({required this.labels, required this.scores});
}

class _BarcodeResult {
  final bool hasQr;
  final String? rawValue;
  final BarcodeType? barcodeType;
  const _BarcodeResult(
      {required this.hasQr, this.rawValue, this.barcodeType});
}

class _ScoreAggregator {
  static Map<ScreenshotCategory, double> aggregate({
    required _OcrResult ocrResult,
    required _LabelResult labelResult,
    required _BarcodeResult barcodeResult,
  }) {
    final scores = <ScreenshotCategory, double>{
      for (final c in ScreenshotCategory.values) c: 0.0,
    };

    void add(ScreenshotCategory cat, double v) =>
        scores[cat] = (scores[cat]! + v).clamp(0.0, 1.0);

    if (barcodeResult.hasQr)            add(ScreenshotCategory.receipt, 0.85);
    if (ocrResult.hasChatBubbles)       add(ScreenshotCategory.chat,    0.75);
    if (ocrResult.hasSubtitles)         add(ScreenshotCategory.movie,   0.65);
    if (ocrResult.hasUrl ||
        ocrResult.hasLongArticleText)   add(ScreenshotCategory.web,     0.60);
    if (ocrResult.hasReceiptKeywords)   add(ScreenshotCategory.receipt, 0.55);
    if (ocrResult.hasVideoProgress)     add(ScreenshotCategory.social,  0.50);

    void addFromLabels(
        List<String> kws, ScreenshotCategory cat, double w) {
      for (final kw in kws) {
        final s = labelResult.scores[kw] ?? 0.0;
        if (s > 0) add(cat, s * w);
      }
    }

    addFromLabels(['movie','film','cinema','television'], ScreenshotCategory.movie,   0.6);
    addFromLabels(['chat','messaging','smartphone'],      ScreenshotCategory.chat,    0.45);
    addFromLabels(['screenshot','text','document'],       ScreenshotCategory.web,     0.4);
    addFromLabels(['qr code','barcode','receipt','ticket'],ScreenshotCategory.receipt,0.70);
    addFromLabels(['meme','cartoon','illustration'],      ScreenshotCategory.meme,    0.55);
    addFromLabels(['video','youtube','instagram','tiktok'],ScreenshotCategory.social, 0.55);

    final maxScore = scores.values.reduce((a, b) => a > b ? a : b);
    if (maxScore < 0.30) scores[ScreenshotCategory.uncategorized] = 0.50;

    return scores;
  }
}
