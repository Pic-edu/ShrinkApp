import '../../data/models/file_item.dart';

class ColdFileDetector {
  static const int _cold30Days = 30;
  static const int _cold60Days = 60;

  static ColdStatus detectStatus(DateTime lastModified) {
    final daysSince = DateTime.now().difference(lastModified).inDays;
    if (daysSince >= _cold60Days) return ColdStatus.cold60;
    if (daysSince >= _cold30Days) return ColdStatus.cold30;
    return ColdStatus.warm;
  }

  static List<FileItem> filterColdFiles(List<FileItem> files) {
    final cold = files.where((f) => f.isCold).toList();
    cold.sort((a, b) {
      if (a.coldStatus != b.coldStatus) {
        return a.coldStatus == ColdStatus.cold60 ? -1 : 1;
      }
      return b.sizeBytes.compareTo(a.sizeBytes);
    });
    return cold;
  }

  static List<FileItem> filterLargeFiles(
    List<FileItem> files, {
    int thresholdBytes = 50 * 1024 * 1024,
  }) {
    final large = files.where((f) => f.sizeBytes >= thresholdBytes).toList();
    large.sort((a, b) => b.sizeBytes.compareTo(a.sizeBytes));
    return large;
  }
}
