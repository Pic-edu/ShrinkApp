import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz_data;

class NotificationService {
  static final NotificationService _i = NotificationService._();
  factory NotificationService() => _i;
  NotificationService._();

  final _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    tz_data.initializeTimeZones();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios     = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: false,
    );
    await _plugin.initialize(
        const InitializationSettings(android: android, iOS: ios));
  }

  Future<bool?> requestPermission() async {
    final impl = _plugin.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();
    return impl?.requestPermissions(alert: true, badge: true);
  }

  Future<void> showImmediate({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    const android = AndroidNotificationDetails(
      'storageShrink_main', 'StorageShrink',
      channelDescription: 'Storage optimization alerts',
      importance: Importance.high, priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );
    const ios = DarwinNotificationDetails(presentAlert: true, presentBadge: true);
    await _plugin.show(id, title, body,
        const NotificationDetails(android: android, iOS: ios),
        payload: payload);
  }

  Future<void> scheduleTrashExpiry({
    required int id,
    required String fileName,
    required DateTime expiresAt,
  }) async {
    final warningTime = expiresAt.subtract(const Duration(days: 2));
    if (warningTime.isBefore(DateTime.now())) return;
    const android = AndroidNotificationDetails(
      'storageShrink_trash', 'Trash Expiry',
      channelDescription: 'Notifications about files expiring from trash',
      importance: Importance.defaultImportance,
    );
    await _plugin.zonedSchedule(
      id,
      'ملف على وشك الحذف النهائي',
      '"$fileName" سيُحذف بشكل دائم خلال يومين',
      tz.TZDateTime.from(warningTime, tz.local),
      const NotificationDetails(
          android: android, iOS: DarwinNotificationDetails()),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> scheduleWeeklyReport() async {
    const android = AndroidNotificationDetails(
      'storageShrink_report', 'Weekly Report',
      channelDescription: 'Weekly storage optimization report',
      importance: Importance.low,
    );
    await _plugin.periodicallyShow(
      999,
      'تقرير التخزين الأسبوعي 📊',
      'اضغط لمراجعة ملفاتك الباردة وتوفير مساحة',
      RepeatInterval.weekly,
      const NotificationDetails(
          android: android, iOS: DarwinNotificationDetails()),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  Future<void> cancelAll() => _plugin.cancelAll();
  Future<void> cancel(int id) => _plugin.cancel(id);
}
