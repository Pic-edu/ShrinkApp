import 'dart:async';
import 'dart:io';
import 'package:archive/archive_io.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:photo_manager/photo_manager.dart';

import '../../data/models/file_item.dart';
import '../../data/models/compression_result.dart';

class CompressionSettings {
  final int imageQuality;
  final bool convertToWebP;
  final bool convertToHEIC;
  final bool compressToColdArchive;

  const CompressionSettings({
    this.imageQuality = 80,
    this.convertToWebP = true,
    this.convertToHEIC = false,
    this.compressToColdArchive = true,
  });
}

class CompressionService {
  static final CompressionService _instance = CompressionService._internal();
  factory CompressionService() => _instance;
  CompressionService._internal();

  Stream<CompressionResult> compressBatch(
    List<FileItem> files,
    CompressionSettings settings,
  ) async* {
    for (final file in files) {
      yield CompressionResult(
        fileId: file.id,
        originalPath: file.path,
        originalSizeBytes: file.sizeBytes,
        status: CompressionStatus.compressing,
        method: _pickMethod(file, settings),
        timestamp: DateTime.now(),
      );
      yield await _compressSingle(file, settings);
    }
  }

  Future<CompressionResult> _compressSingle(
      FileItem file, CompressionSettings settings) async {
    final method = _pickMethod(file, settings);
    try {
      switch (method) {
        case CompressionMethod.webp:
          return await _compressImageWebP(file, settings);
        case CompressionMethod.heic:
          return await _compressImageHEIC(file, settings);
        case CompressionMethod.zip:
        case CompressionMethod.lzma:
          return await _compressToArchive(file, method);
        case CompressionMethod.h265:
          return _skipVideo(file);
      }
    } catch (e) {
      return CompressionResult(
        fileId: file.id,
        originalPath: file.path,
        originalSizeBytes: file.sizeBytes,
        status: CompressionStatus.failed,
        method: method,
        errorMessage: e.toString(),
        timestamp: DateTime.now(),
      );
    }
  }

  CompressionMethod _pickMethod(FileItem file, CompressionSettings settings) {
    switch (file.type) {
      case FileType.image:
        if (Platform.isIOS && settings.convertToHEIC) return CompressionMethod.heic;
        return CompressionMethod.webp;
      case FileType.video:
        return CompressionMethod.h265;
      default:
        return settings.compressToColdArchive
            ? CompressionMethod.zip
            : CompressionMethod.lzma;
    }
  }

  Future<CompressionResult> _compressImageWebP(
      FileItem file, CompressionSettings settings) async {
    final outDir  = await _getOutputDir('images');
    final outName = '${p.basenameWithoutExtension(file.name)}.webp';
    final outPath = p.join(outDir.path, outName);

    final result = await FlutterImageCompress.compressAndGetFile(
      file.path, outPath,
      quality: settings.imageQuality,
      format: CompressFormat.webp,
      keepExif: false,
    );

    if (result == null) {
      return CompressionResult(
        fileId: file.id, originalPath: file.path,
        originalSizeBytes: file.sizeBytes,
        status: CompressionStatus.failed,
        method: CompressionMethod.webp,
        errorMessage: 'flutter_image_compress returned null',
        timestamp: DateTime.now(),
      );
    }

    final compressedSize = await result.length();
    if (compressedSize >= file.sizeBytes) {
      await result.delete();
      return CompressionResult(
        fileId: file.id, originalPath: file.path,
        originalSizeBytes: file.sizeBytes,
        compressedSizeBytes: file.sizeBytes,
        status: CompressionStatus.skipped,
        method: CompressionMethod.webp,
        timestamp: DateTime.now(),
      );
    }

    return CompressionResult(
      fileId: file.id, originalPath: file.path,
      compressedPath: result.path,
      originalSizeBytes: file.sizeBytes,
      compressedSizeBytes: compressedSize,
      status: CompressionStatus.done,
      method: CompressionMethod.webp,
      timestamp: DateTime.now(),
    );
  }

  Future<CompressionResult> _compressImageHEIC(
      FileItem file, CompressionSettings settings) async {
    final outDir  = await _getOutputDir('images');
    final outName = '${p.basenameWithoutExtension(file.name)}.heic';
    final outPath = p.join(outDir.path, outName);

    final result = await FlutterImageCompress.compressAndGetFile(
      file.path, outPath,
      quality: settings.imageQuality,
      format: CompressFormat.heic,
      keepExif: false,
    );

    if (result == null) return _compressImageWebP(file, settings);

    final compressedSize = await result.length();
    if (compressedSize >= file.sizeBytes) {
      await result.delete();
      return CompressionResult(
        fileId: file.id, originalPath: file.path,
        originalSizeBytes: file.sizeBytes,
        compressedSizeBytes: file.sizeBytes,
        status: CompressionStatus.skipped,
        method: CompressionMethod.heic,
        timestamp: DateTime.now(),
      );
    }

    if (file.photoAsset != null) {
      await PhotoManager.editor.saveImageWithPath(result.path, title: outName);
    }

    return CompressionResult(
      fileId: file.id, originalPath: file.path,
      compressedPath: result.path,
      originalSizeBytes: file.sizeBytes,
      compressedSizeBytes: compressedSize,
      status: CompressionStatus.done,
      method: CompressionMethod.heic,
      timestamp: DateTime.now(),
    );
  }

  Future<CompressionResult> _compressToArchive(
      FileItem file, CompressionMethod method) async {
    final archiveDir = await _getOutputDir('archives');
    final outPath    = p.join(archiveDir.path,
        '${p.basenameWithoutExtension(file.name)}.zip');

    final inputBytes = await File(file.path).readAsBytes();
    final archive    = Archive();
    archive.addFile(ArchiveFile(file.name, inputBytes.length, inputBytes));

    final List<int> encoded = method == CompressionMethod.lzma
        ? BZip2Encoder().encode(inputBytes)
        : ZipEncoder().encode(archive) ?? [];

    if (encoded.isEmpty) {
      return CompressionResult(
        fileId: file.id, originalPath: file.path,
        originalSizeBytes: file.sizeBytes,
        status: CompressionStatus.failed, method: method,
        errorMessage: 'Encoder returned empty output',
        timestamp: DateTime.now(),
      );
    }

    final outFile = File(outPath);
    await outFile.writeAsBytes(encoded);

    if (encoded.length >= file.sizeBytes) {
      await outFile.delete();
      return CompressionResult(
        fileId: file.id, originalPath: file.path,
        originalSizeBytes: file.sizeBytes,
        compressedSizeBytes: file.sizeBytes,
        status: CompressionStatus.skipped, method: method,
        timestamp: DateTime.now(),
      );
    }

    return CompressionResult(
      fileId: file.id, originalPath: file.path,
      compressedPath: outPath,
      originalSizeBytes: file.sizeBytes,
      compressedSizeBytes: encoded.length,
      status: CompressionStatus.done, method: method,
      timestamp: DateTime.now(),
    );
  }

  CompressionResult _skipVideo(FileItem file) => CompressionResult(
    fileId: file.id, originalPath: file.path,
    originalSizeBytes: file.sizeBytes,
    compressedSizeBytes: file.sizeBytes,
    status: CompressionStatus.skipped,
    method: CompressionMethod.h265,
    errorMessage: 'H.265 requires ffmpeg_kit_flutter',
    timestamp: DateTime.now(),
  );

  Future<String?> decompressForViewing(String zipPath) async {
    try {
      final tempDir = await getTemporaryDirectory();
      final outDir  = Directory(p.join(tempDir.path, 'preview_cache'));
      await outDir.create(recursive: true);
      final bytes   = await File(zipPath).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final entry in archive) {
        if (entry.isFile) {
          final outPath = p.join(outDir.path, entry.name);
          await File(outPath).writeAsBytes(entry.content as List<int>);
          return outPath;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<Directory> _getOutputDir(String sub) async {
    final base = await getApplicationDocumentsDirectory();
    final dir  = Directory(p.join(base.path, 'StorageShrink', sub));
    await dir.create(recursive: true);
    return dir;
  }
}
