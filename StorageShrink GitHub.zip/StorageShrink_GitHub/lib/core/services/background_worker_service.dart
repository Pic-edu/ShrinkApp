import 'dart:io';
import 'package:workmanager/workmanager.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'trash_manager_service.dart';
import 'notification_service.dart';

class WorkerTasks {
  static const purgeTrash   = 'ss_purge_trash';
  static const weeklyReport = 'ss_weekly_report';
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    await Hive.initFlutter();
    switch (taskName) {
      case WorkerTasks.purgeTrash:
        return _runPurgeTrash();
      case WorkerTasks.weeklyReport:
        return _runWeeklyReport();
      default:
        return true;
    }
  });
}

Future<bool> _runPurgeTrash() async {
  try {
    final purged = await TrashManagerService().purgeExpired();
    if (purged > 0) {
      await NotificationService().init();
      await NotificationService().showImmediate(
        id: 1001,
        title: 'تم تنظيف السلة 🗑️',
        body: 'تم حذف $purged ملف منتهي الصلاحية نهائياً',
      );
    }
    return true;
  } catch (_) { return false; }
}

Future<bool> _runWeeklyReport() async {
  try {
    await NotificationService().init();
    await NotificationService().showImmediate(
      id: 1002,
      title: 'حان وقت تنظيف مساحتك! 🧹',
      body: 'لديك ملفات باردة تنتظرك — اضغط لتوفير مساحة',
      payload: 'open_categories',
    );
    return true;
  } catch (_) { return false; }
}

class BackgroundWorkerService {
  static final BackgroundWorkerService _i = BackgroundWorkerService._();
  factory BackgroundWorkerService() => _i;
  BackgroundWorkerService._();

  Future<void> init() async {
    if (!Platform.isAndroid) return;
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  }

  Future<void> registerPurgeTask() async {
    if (!Platform.isAndroid) return;
    await Workmanager().registerPeriodicTask(
      WorkerTasks.purgeTrash, WorkerTasks.purgeTrash,
      frequency: const Duration(hours: 24),
      constraints: Constraints(
        networkType: NetworkType.not_required,
        requiresBatteryNotLow: true,
        requiresDeviceIdle: true,
      ),
      existingWorkPolicy: ExistingWorkPolicy.keep,
    );
  }

  Future<void> registerWeeklyReport() async {
    if (!Platform.isAndroid) return;
    await Workmanager().registerPeriodicTask(
      WorkerTasks.weeklyReport, WorkerTasks.weeklyReport,
      frequency: const Duration(days: 7),
      constraints: Constraints(networkType: NetworkType.not_required),
      existingWorkPolicy: ExistingWorkPolicy.keep,
    );
  }

  Future<void> triggerImmediatePurge() async {
    if (!Platform.isAndroid) {
      await _runPurgeTrash();
      return;
    }
    await Workmanager().registerOneOffTask(
      '${WorkerTasks.purgeTrash}_manual',
      WorkerTasks.purgeTrash,
      constraints: Constraints(networkType: NetworkType.not_required),
    );
  }

  Future<void> cancelAll() => Workmanager().cancelAll();
}
