import 'dart:io';
import 'dart:async';
import 'package:path_provider/path_provider.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:uuid/uuid.dart';

import '../../data/models/file_item.dart';
import 'cold_file_detector.dart';

class StorageScannerService {
  static final StorageScannerService _instance =
      StorageScannerService._internal();
  factory StorageScannerService() => _instance;
  StorageScannerService._internal();

  static const _uuid = Uuid();

  Stream<ScanResult> scan() async* {
    final allFiles = <FileItem>[];
    int scanned = 0;

    yield const ScanResult(progressPercent: 0.05);

    final photoAlbums = await PhotoManager.getAssetPathList(
      type: RequestType.all,
      filterOption: FilterOptionGroup(
        imageOption: const FilterOption(sizeConstraint: SizeConstraint()),
        videoOption: const FilterOption(sizeConstraint: SizeConstraint()),
      ),
    );

    int totalAssets = 0;
    for (final album in photoAlbums) {
      totalAssets += await album.assetCountAsync;
    }

    for (final album in photoAlbums) {
      final count = await album.assetCountAsync;
      if (count == 0) continue;
      const pageSize = 100;
      int page = 0;
      while (true) {
        final assets =
            await album.getAssetListPaged(page: page, size: pageSize);
        if (assets.isEmpty) break;
        for (final asset in assets) {
          final file = await _assetToFileItem(asset);
          if (file != null) {
            allFiles.add(file);
            scanned++;
          }
        }
        final progress = 0.05 +
            (scanned / (totalAssets > 0 ? totalAssets : 1)) * 0.55;
        yield ScanResult(
          allFiles: List.from(allFiles),
          coldFiles: ColdFileDetector.filterColdFiles(allFiles),
          largeFiles: ColdFileDetector.filterLargeFiles(allFiles),
          scannedCount: scanned,
          progressPercent: progress.clamp(0.0, 0.6),
        );
        page++;
        if (assets.length < pageSize) break;
      }
    }

    if (Platform.isAndroid) {
      final docFiles = await _scanDocumentDirectories();
      allFiles.addAll(docFiles);
      scanned += docFiles.length;
    }

    final cacheFiles = await _scanCacheDirectories();
    allFiles.addAll(cacheFiles);
    scanned += cacheFiles.length;

    yield ScanResult(
      allFiles: List.from(allFiles),
      coldFiles: ColdFileDetector.filterColdFiles(allFiles),
      largeFiles: ColdFileDetector.filterLargeFiles(allFiles),
      scannedCount: scanned,
      progressPercent: 1.0,
      isComplete: true,
    );
  }

  Future<FileItem?> _assetToFileItem(AssetEntity asset) async {
    try {
      final file = await asset.file;
      if (file == null) return null;
      final stat = await file.stat();
      final coldStatus =
          ColdFileDetector.detectStatus(asset.modifiedDateTime ?? stat.modified);
      return FileItem(
        id: _uuid.v4(),
        name: asset.title ?? file.uri.pathSegments.last,
        path: file.path,
        sizeBytes: asset.size > 0 ? asset.size : stat.size,
        lastModified: asset.modifiedDateTime ?? stat.modified,
        lastAccessed: stat.accessed,
        type: asset.type == AssetType.video ? FileType.video : FileType.image,
        coldStatus: coldStatus,
        photoAsset: asset,
      );
    } catch (_) {
      return null;
    }
  }

  Future<List<FileItem>> _scanDocumentDirectories() async {
    final dirs = <Directory>[];
    final externalDirs = await getExternalStorageDirectories();
    if (externalDirs != null) {
      for (final d in externalDirs) {
        final root = d.parent.parent.parent.parent;
        dirs.addAll([
          Directory('${root.path}/Documents'),
          Directory('${root.path}/Downloads'),
          Directory('${root.path}/WhatsApp/Media'),
          Directory('${root.path}/Telegram'),
        ]);
      }
    }
    final files = <FileItem>[];
    for (final dir in dirs) {
      if (await dir.exists()) {
        await for (final entity
            in dir.list(recursive: true, followLinks: false)) {
          if (entity is File) {
            final item = await _fileToFileItem(entity);
            if (item != null) files.add(item);
          }
        }
      }
    }
    return files;
  }

  Future<List<FileItem>> _scanCacheDirectories() async {
    final files = <FileItem>[];
    try {
      final tempDir = await getTemporaryDirectory();
      await for (final entity in tempDir.list(recursive: true)) {
        if (entity is File) {
          final item = await _fileToFileItem(entity, isCache: true);
          if (item != null) files.add(item);
        }
      }
    } catch (_) {}
    return files;
  }

  Future<FileItem?> _fileToFileItem(File file,
      {bool isCache = false}) async {
    try {
      final stat = await file.stat();
      if (stat.size == 0) return null;
      final name = file.uri.pathSegments.last;
      final ext  = name.contains('.') ? name.split('.').last.toLowerCase() : '';
      return FileItem(
        id: _uuid.v4(),
        name: name,
        path: file.path,
        sizeBytes: stat.size,
        lastModified: stat.modified,
        lastAccessed: stat.accessed,
        type: _detectFileType(ext),
        coldStatus: isCache
            ? ColdStatus.cold60
            : ColdFileDetector.detectStatus(stat.modified),
      );
    } catch (_) {
      return null;
    }
  }

  static FileType _detectFileType(String ext) {
    const imageExts = {'jpg','jpeg','png','gif','bmp','webp','heic','heif','tiff'};
    const videoExts = {'mp4','mov','avi','mkv','webm','m4v','3gp','ts'};
    const docExts   = {'pdf','doc','docx','xls','xlsx','ppt','pptx','txt','csv'};
    const audioExts = {'mp3','aac','flac','wav','ogg','m4a','opus'};
    if (imageExts.contains(ext)) return FileType.image;
    if (videoExts.contains(ext)) return FileType.video;
    if (docExts.contains(ext))   return FileType.document;
    if (audioExts.contains(ext)) return FileType.audio;
    if (ext == 'apk')            return FileType.apk;
    return FileType.other;
  }
}
