import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../data/models/file_item.dart';
import '../../../data/models/trash_item.dart';
import '../../providers/trash_provider.dart';

class SmartTrashScreen extends ConsumerWidget {
  const SmartTrashScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trashAsync = ref.watch(trashProvider);
    final theme      = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('سلة المهملات الذكية'),
        backgroundColor: Colors.transparent, elevation: 0,
        actions: [
          trashAsync.maybeWhen(
            data: (items) => items.isEmpty ? const SizedBox.shrink()
                : TextButton.icon(
                    onPressed: () => _confirmEmptyTrash(context, ref),
                    icon: const Icon(Icons.delete_sweep, size: 18),
                    label: const Text('إفراغ'),
                    style: TextButton.styleFrom(
                        foregroundColor: theme.colorScheme.error)),
            orElse: () => const SizedBox.shrink(),
          ),
        ],
      ),
      body: trashAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('خطأ: $e')),
        data: (items) => items.isEmpty ? _EmptyState() : _Body(items: items),
      ),
    );
  }

  Future<void> _confirmEmptyTrash(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(context: context,
      builder: (_) => AlertDialog(
        title: const Text('إفراغ السلة؟'),
        content: const Text('سيتم حذف جميع الملفات نهائياً ولا يمكن التراجع.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف نهائي')),
        ],
      ));
    if (confirmed == true) await ref.read(trashProvider.notifier).emptyTrash();
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Column(
      mainAxisAlignment: MainAxisAlignment.center, children: [
      Text('🗑️', style: const TextStyle(fontSize: 64))
          .animate().scale(begin: const Offset(0.5, 0.5), curve: Curves.elasticOut),
      const SizedBox(height: 16),
      Text('السلة فارغة',
          style: Theme.of(context).textTheme.titleMedium
              ?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('الملفات المحذوفة تُحتجز هنا لمدة 14 يوماً',
          style: Theme.of(context).textTheme.bodySmall, textAlign: TextAlign.center),
    ]));
  }
}

class _Body extends ConsumerWidget {
  final List<TrashItem> items;
  const _Body({required this.items});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme        = Theme.of(context);
    final totalSize    = items.fold(0, (s, i) => s + i.sizeBytes);
    final expiredCount = items.where((i) => i.state == TrashItemState.expired).length;

    return Column(children: [
      Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16)),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _Stat(label: 'إجمالي', value: '${items.length}', emoji: '📁'),
          _Stat(label: 'الحجم',  value: _fmt(totalSize),    emoji: '💾'),
          if (expiredCount > 0)
            _Stat(label: 'منتهية', value: '$expiredCount', emoji: '⚠️',
                color: theme.colorScheme.error),
        ]),
      ).animate().fadeIn().slideY(begin: -0.2),

      if (expiredCount > 0)
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: theme.colorScheme.errorContainer,
            borderRadius: BorderRadius.circular(14)),
          child: Row(children: [
            const Text('⚠️', style: TextStyle(fontSize: 20)),
            const SizedBox(width: 10),
            Expanded(child: Text('$expiredCount ملف انتهت صلاحيته',
                style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onErrorContainer))),
            TextButton(
              onPressed: () => ref.read(trashProvider.notifier).purgeExpired(),
              child: Text('تنظيف', style: TextStyle(color: theme.colorScheme.error))),
          ]),
        ).animate().fadeIn(delay: 100.ms),

      Expanded(child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: items.length,
        itemBuilder: (_, i) => _TrashTile(
          item: items[i],
          onRestore: () => ref.read(trashProvider.notifier).restore(items[i].id),
          onDelete:  () => ref.read(trashProvider.notifier).permanentlyDelete(items[i].id),
        ).animate(delay: (i * 40).ms).fadeIn().slideX(begin: 0.2),
      )),
    ]);
  }

  String _fmt(int b) {
    if (b >= 1024 * 1024 * 1024) return '${(b / (1024*1024*1024)).toStringAsFixed(1)} GB';
    return '${(b / (1024*1024)).toStringAsFixed(0)} MB';
  }
}

class _TrashTile extends StatelessWidget {
  final TrashItem item;
  final VoidCallback onRestore, onDelete;
  const _TrashTile({required this.item, required this.onRestore, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final theme     = Theme.of(context);
    final isExpired = item.state == TrashItemState.expired;
    final isSoon    = item.state == TrashItemState.expiringSoon;
    final statusClr = isExpired ? theme.colorScheme.error
        : isSoon ? Colors.orange : theme.colorScheme.onSurface.withOpacity(0.4);

    return Dismissible(
      key: Key(item.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(color: theme.colorScheme.error,
            borderRadius: BorderRadius.circular(14)),
        child: const Icon(Icons.delete_forever, color: Colors.white)),
      onDismissed: (_) => onDelete(),
      confirmDismiss: (_) => showDialog<bool>(context: context,
        builder: (_) => AlertDialog(
          title: const Text('حذف نهائي؟'),
          content: Text('سيتم حذف "${item.name}" نهائياً.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false),
                child: const Text('إلغاء')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: theme.colorScheme.error),
              onPressed: () => Navigator.pop(context, true),
              child: const Text('حذف')),
          ])),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: isExpired
              ? theme.colorScheme.errorContainer.withOpacity(0.3)
              : theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(14),
          border: isExpired ? Border.all(
              color: theme.colorScheme.error.withOpacity(0.3)) : null),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          leading: Container(width: 44, height: 44,
            decoration: BoxDecoration(color: theme.colorScheme.surface,
                borderRadius: BorderRadius.circular(10)),
            child: Center(child: Text(_typeEmoji(item.fileType),
                style: const TextStyle(fontSize: 20)))),
          title: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
          subtitle: Row(children: [
            Text(item.sizeFormatted, style: theme.textTheme.bodySmall),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(color: statusClr.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8)),
              child: Text(
                isExpired ? 'منتهي'
                    : isSoon  ? '${item.daysRemaining}ي متبقية'
                    : '${item.daysRemaining} يوم',
                style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                    color: statusClr))),
          ]),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(icon: const Icon(Icons.restore, size: 20),
                tooltip: 'استعادة', onPressed: onRestore),
            IconButton(icon: Icon(Icons.delete_forever, size: 20,
                color: theme.colorScheme.error),
                tooltip: 'حذف نهائي', onPressed: onDelete),
          ]),
        ),
      ),
    );
  }

  String _typeEmoji(FileType t) => switch (t) {
    FileType.image => '🖼️', FileType.video => '🎬',
    FileType.document => '📄', FileType.audio => '🎵',
    FileType.apk => '📦', _ => '📁',
  };
}

class _Stat extends StatelessWidget {
  final String label, value, emoji; final Color? color;
  const _Stat({required this.label, required this.value,
      required this.emoji, this.color});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(children: [
      Text(emoji, style: const TextStyle(fontSize: 20)),
      const SizedBox(height: 4),
      Text(value, style: theme.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w700,
          color: color ?? theme.colorScheme.onSurface)),
      Text(label, style: theme.textTheme.labelSmall),
    ]);
  }
}
