import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../data/models/screenshot_category.dart';
import '../../providers/classifier_provider.dart';

class SmartGalleryScreen extends ConsumerWidget {
  const SmartGalleryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final batchAsync = ref.watch(classificationProvider);
    final selectedCat= ref.watch(selectedCategoryProvider);
    final theme      = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('المعرض الذكي'),
        backgroundColor: Colors.transparent, elevation: 0,
        actions: [
          Padding(padding: const EdgeInsets.only(right: 12),
            child: TextButton.icon(
              onPressed: () =>
                  ref.read(classificationProvider.notifier).classifyScreenshots(),
              icon: const Icon(Icons.auto_awesome, size: 18),
              label: const Text('تصنيف'),
            )),
        ],
      ),
      body: batchAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('خطأ: $e')),
        data: (batch) {
          if (batch == null) return Center(child: Column(
            mainAxisAlignment: MainAxisAlignment.center, children: [
              const Text('🤖', style: TextStyle(fontSize: 56)),
              const SizedBox(height: 16),
              const Text('اضغط "تصنيف" لتحليل لقطات الشاشة',
                  textAlign: TextAlign.center),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: () => ref
                    .read(classificationProvider.notifier).classifyScreenshots(),
                icon: const Icon(Icons.auto_awesome),
                label: const Text('بدء التصنيف الذكي'),
              ),
            ],
          ));

          final grouped = batch.grouped;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (!batch.isComplete) ...[
                LinearProgressIndicator(value: batch.progressPercent),
                const SizedBox(height: 12),
              ],
              SizedBox(
                height: 110,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: ScreenshotCategory.values
                      .where((c) => c != ScreenshotCategory.uncategorized &&
                          (grouped[c]?.isNotEmpty ?? false))
                      .map((cat) => Padding(
                            padding: const EdgeInsets.only(right: 12),
                            child: _CategoryFolder(
                              category: cat,
                              count: grouped[cat]?.length ?? 0,
                              isSelected: selectedCat == cat,
                              onTap: () => ref
                                  .read(selectedCategoryProvider.notifier)
                                  .state = selectedCat == cat ? null : cat,
                            ),
                          )).toList(),
                ),
              ).animate().fadeIn(delay: 100.ms),
              const SizedBox(height: 20),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, mainAxisSpacing: 4,
                  crossAxisSpacing: 4, childAspectRatio: 0.65),
                itemCount: ref.watch(filteredScreenshotsProvider).length,
                itemBuilder: (_, i) {
                  final r = ref.watch(filteredScreenshotsProvider)[i];
                  return _ScreenshotTile(result: r)
                      .animate(delay: (i * 20).ms).fadeIn();
                },
              ),
            ],
          );
        },
      ),
    );
  }
}

class _CategoryFolder extends StatelessWidget {
  final ScreenshotCategory category;
  final int count; final bool isSelected; final VoidCallback onTap;
  const _CategoryFolder({required this.category, required this.count,
      required this.isSelected, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 88,
        decoration: BoxDecoration(
          color: isSelected
              ? theme.colorScheme.primaryContainer
              : theme.colorScheme.surfaceVariant,
          borderRadius: BorderRadius.circular(16),
          border: isSelected
              ? Border.all(color: theme.colorScheme.primary, width: 2)
              : Border.all(color: Colors.transparent),
        ),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(category.emoji, style: const TextStyle(fontSize: 26)),
          const SizedBox(height: 6),
          Text(category.labelAr, textAlign: TextAlign.center, maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w600,
                  color: isSelected ? theme.colorScheme.primary : null)),
          Text('$count', style: theme.textTheme.labelSmall
              ?.copyWith(color: theme.colorScheme.onSurface.withOpacity(0.5))),
        ]),
      ),
    );
  }
}

class _ScreenshotTile extends ConsumerWidget {
  final ClassificationResult result;
  const _ScreenshotTile({required this.result});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return GestureDetector(
      onLongPress: () => showModalBottomSheet(
        context: context,
        builder: (_) => _CorrectionSheet(result: result,
          onSelect: (cat) {
            ref.read(classificationProvider.notifier)
                .correctCategory(result.fileId, cat);
            Navigator.pop(context);
          }),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Stack(fit: StackFit.expand, children: [
          Image.file(File(result.filePath), fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                  color: theme.colorScheme.surfaceVariant,
                  child: const Icon(Icons.image_not_supported, size: 24))),
          Positioned(top: 6, right: 6,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
              decoration: BoxDecoration(color: Colors.black.withOpacity(0.55),
                  borderRadius: BorderRadius.circular(8)),
              child: Text(result.category.emoji, style: const TextStyle(fontSize: 13)),
            )),
          if (!result.isHighConfidence)
            Positioned(bottom: 0, left: 0, right: 0,
              child: Container(padding: const EdgeInsets.symmetric(vertical: 3),
                color: Colors.orange.withOpacity(0.75),
                child: const Text('؟ تحقق', textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)))),
        ]),
      ),
    );
  }
}

class _CorrectionSheet extends StatelessWidget {
  final ClassificationResult result;
  final void Function(ScreenshotCategory) onSelect;
  const _CorrectionSheet({required this.result, required this.onSelect});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(child: Padding(padding: const EdgeInsets.all(20),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('تصحيح التصنيف',
            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        Wrap(spacing: 8, runSpacing: 8,
          children: ScreenshotCategory.values
              .where((c) => c != ScreenshotCategory.uncategorized)
              .map((cat) => ActionChip(
                avatar: Text(cat.emoji), label: Text(cat.labelAr),
                backgroundColor: cat == result.category
                    ? theme.colorScheme.primaryContainer : null,
                onPressed: () => onSelect(cat))).toList()),
      ])));
  }
}
