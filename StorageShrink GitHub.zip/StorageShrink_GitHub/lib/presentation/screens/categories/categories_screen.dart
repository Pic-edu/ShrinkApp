import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../data/models/file_item.dart';
import '../../providers/scan_provider.dart';
import '../../providers/compression_provider.dart';
import '../../providers/trash_provider.dart';

class CategoriesScreen extends ConsumerWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n     = AppLocalizations.of(context)!;
    final scanAsync= ref.watch(scanStreamProvider);
    final theme    = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.categories),
        backgroundColor: Colors.transparent, elevation: 0,
        actions: [
          scanAsync.maybeWhen(
            data: (r) => !r.isComplete
                ? Padding(padding: const EdgeInsets.only(right: 16),
                    child: SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(
                            value: r.progressPercent, strokeWidth: 2.5)))
                : const SizedBox.shrink(),
            orElse: () => const SizedBox.shrink(),
          ),
        ],
      ),
      body: scanAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('خطأ: $e')),
        data: (result) => _Body(result: result),
      ),
    );
  }
}

class _Body extends ConsumerWidget {
  final ScanResult result;
  const _Body({required this.result});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme    = Theme.of(context);
    final selected = ref.watch(selectedFilesProvider);
    final filter   = ref.watch(scanFilterProvider);

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (!result.isComplete) ...[
          LinearProgressIndicator(value: result.progressPercent),
          const SizedBox(height: 8),
          Text('${result.scannedCount} ملف تم فحصه...',
              style: theme.textTheme.labelMedium),
          const SizedBox(height: 16),
        ],

        if (result.coldFiles.isNotEmpty)
          _ColdBanner(coldFiles: result.coldFiles, onCompress: () {
            final notifier = ref.read(compressionBatchProvider.notifier);
            notifier.startBatch(result.coldFiles.take(20).toList());
          }).animate().fadeIn().slideY(begin: -0.2),

        const SizedBox(height: 20),

        Wrap(spacing: 8, children: ScanFilter.values.map((f) => FilterChip(
          label: Text(switch (f) {
            ScanFilter.all    => 'الكل',
            ScanFilter.cold30 => '30 يوم',
            ScanFilter.cold60 => '60 يوم',
            ScanFilter.large  => 'الأكبر',
          }),
          selected: filter == f,
          onSelected: (_) =>
              ref.read(scanFilterProvider.notifier).state = f,
        )).toList()),

        const SizedBox(height: 16),

        _TypeBreakdown(result: result).animate().fadeIn(delay: 100.ms),

        const SizedBox(height: 20),

        if (selected.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(children: [
              Expanded(child: Text('تم تحديد ${selected.length} ملف',
                  style: theme.textTheme.labelLarge)),
              FilledButton.tonal(
                onPressed: () {
                  final files = result.coldFiles
                      .where((f) => selected.contains(f.id)).toList();
                  ref.read(trashProvider.notifier).sendToTrash(files);
                  ref.read(selectedFilesProvider.notifier).clearAll();
                },
                child: const Text('إرسال للسلة'),
              ),
            ]),
          ),

        ...ref.watch(filteredFilesProvider).take(40).map((file) =>
          _FileRow(file: file, isSelected: selected.contains(file.id))
              .animate().fadeIn().slideX(begin: 0.2)),
      ],
    );
  }
}

class _ColdBanner extends StatelessWidget {
  final List<FileItem> coldFiles;
  final VoidCallback onCompress;
  const _ColdBanner({required this.coldFiles, required this.onCompress});

  @override
  Widget build(BuildContext context) {
    final theme    = Theme.of(context);
    final totalMB  = coldFiles.fold(0, (s, f) => s + f.sizeBytes) ~/ (1024 * 1024);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withOpacity(0.4),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.primary.withOpacity(0.3)),
      ),
      child: Row(children: [
        Container(padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: theme.colorScheme.primary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12)),
            child: const Text('❄️', style: TextStyle(fontSize: 24))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${coldFiles.length} ملف بارد',
              style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          Text('يمكن توفير $totalMB MB من المساحة',
              style: theme.textTheme.bodySmall),
        ])),
        FilledButton(onPressed: onCompress, child: const Text('ضغط')),
      ]),
    );
  }
}

class _TypeBreakdown extends StatelessWidget {
  final ScanResult result;
  const _TypeBreakdown({required this.result});
  @override
  Widget build(BuildContext context) {
    final theme   = Theme.of(context);
    final grouped = result.grouped;
    final types   = [
      (FileType.image,    '🖼️', 'صور'),
      (FileType.video,    '🎬', 'فيديو'),
      (FileType.document, '📄', 'مستندات'),
      (FileType.audio,    '🎵', 'صوتيات'),
    ];
    return GridView.count(
      crossAxisCount: 2, shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.5,
      children: types.map((t) {
        final files = grouped[t.$1] ?? [];
        final sizeMB = files.fold(0, (s, f) => s + f.sizeBytes) / (1024 * 1024);
        return Container(
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceVariant,
            borderRadius: BorderRadius.circular(14)),
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.$2, style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 6),
            Text(t.$3, style: theme.textTheme.labelLarge?.copyWith(fontWeight: FontWeight.bold)),
            Text('${files.length} ملف · ${sizeMB.toStringAsFixed(0)} MB',
                style: theme.textTheme.bodySmall),
          ]),
        );
      }).toList(),
    );
  }
}

class _FileRow extends ConsumerWidget {
  final FileItem file; final bool isSelected;
  const _FileRow({required this.file, required this.isSelected});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isSelected
            ? theme.colorScheme.primaryContainer.withOpacity(0.5)
            : theme.colorScheme.surfaceVariant,
        borderRadius: BorderRadius.circular(12),
        border: isSelected ? Border.all(color: theme.colorScheme.primary, width: 1.5) : null,
      ),
      child: ListTile(
        onTap: () => ref.read(selectedFilesProvider.notifier).toggle(file.id),
        leading: Text(_typeEmoji(file.type), style: const TextStyle(fontSize: 22)),
        title: Text(file.name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
        subtitle: Text(file.sizeFormatted, style: theme.textTheme.bodySmall),
        trailing: isSelected
            ? Icon(Icons.check_circle, color: theme.colorScheme.primary)
            : Icon(Icons.circle_outlined,
                color: theme.colorScheme.onSurface.withOpacity(0.3)),
      ),
    );
  }

  String _typeEmoji(FileType t) => switch (t) {
    FileType.image => '🖼️', FileType.video => '🎬',
    FileType.document => '📄', FileType.audio => '🎵',
    FileType.apk => '📦', _ => '📁',
  };
}
