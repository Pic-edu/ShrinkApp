import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../../data/models/badge_model.dart';
import '../../providers/gamification_provider.dart';

class BadgesScreen extends ConsumerWidget {
  const BadgesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final gamif = ref.watch(gamificationProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('الإنجازات والشارات')),
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: _XPBanner(
          totalXP: gamif.totalXP, badgeCount: gamif.unlockedBadges.length)
            .animate().fadeIn().slideY(begin: -0.2)),
        SliverToBoxAdapter(child: _NextBadgeProgress(
          totalXP: gamif.totalXP, unlocked: gamif.unlockedBadges)
            .animate().fadeIn(delay: 100.ms)),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 12,
              crossAxisSpacing: 12, childAspectRatio: 1.05),
            delegate: SliverChildBuilderDelegate((_, i) {
              final badge    = BadgeModel.all[i];
              final unlocked = gamif.unlockedBadges.contains(badge.id);
              return _BadgeCard(badge: badge, isUnlocked: unlocked,
                      totalXP: gamif.totalXP)
                  .animate(delay: (i * 60).ms).fadeIn()
                  .scale(begin: const Offset(0.85, 0.85), curve: Curves.elasticOut);
            }, childCount: BadgeModel.all.length),
          ),
        ),
      ]),
    );
  }
}

class _XPBanner extends StatelessWidget {
  final int totalXP, badgeCount;
  const _XPBanner({required this.totalXP, required this.badgeCount});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
          color: const Color(0xFF534AB7), borderRadius: BorderRadius.circular(20)),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('إجمالي نقاط الخبرة',
              style: theme.textTheme.labelMedium?.copyWith(color: Colors.white.withOpacity(0.7))),
          const SizedBox(height: 4),
          Text('$totalXP XP',
              style: theme.textTheme.headlineMedium?.copyWith(color: Colors.white, fontWeight: FontWeight.w800)),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          const Text('⭐', style: TextStyle(fontSize: 32)),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20)),
            child: Text('$badgeCount / ${BadgeModel.all.length} شارة',
                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700))),
        ]),
      ]),
    );
  }
}

class _NextBadgeProgress extends StatelessWidget {
  final int totalXP; final List<String> unlocked;
  const _NextBadgeProgress({required this.totalXP, required this.unlocked});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final next  = BadgeModel.all
        .where((b) => !unlocked.contains(b.id)).cast<BadgeModel?>()
        .firstWhere((_) => true, orElse: () => null);

    if (next == null) {
      return Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Container(padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: const Color(0xFFE1F5EE),
              borderRadius: BorderRadius.circular(14)),
          child: const Row(children: [
            Text('🎉', style: TextStyle(fontSize: 22)),
            SizedBox(width: 10),
            Text('لقد فتحت جميع الشارات!',
                style: TextStyle(color: Color(0xFF0F6E56), fontWeight: FontWeight.w600)),
          ])));
    }

    final progress = (totalXP / next.xpRequired).clamp(0.0, 1.0);
    return Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Container(padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: theme.colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(next.emoji, style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 8),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('التالية: ${next.nameAr}', style: theme.textTheme.titleSmall),
              Text('$totalXP / ${next.xpRequired} XP', style: theme.textTheme.bodySmall),
            ])),
            Text('${(progress * 100).toInt()}%',
                style: const TextStyle(color: Color(0xFF534AB7), fontWeight: FontWeight.w700, fontSize: 14)),
          ]),
          const SizedBox(height: 10),
          ClipRRect(borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(value: progress, minHeight: 8,
              backgroundColor: theme.colorScheme.outline.withOpacity(0.1),
              valueColor: const AlwaysStoppedAnimation(Color(0xFF534AB7)))),
        ])));
  }
}

class _BadgeCard extends StatelessWidget {
  final BadgeModel badge; final bool isUnlocked; final int totalXP;
  const _BadgeCard({required this.badge, required this.isUnlocked, required this.totalXP});

  Color _rc(BadgeRarity r) => switch (r) {
    BadgeRarity.common    => const Color(0xFF888780),
    BadgeRarity.rare      => const Color(0xFF1D9E75),
    BadgeRarity.epic      => const Color(0xFF534AB7),
    BadgeRarity.legendary => const Color(0xFFBA7517),
  };

  String _rl(BadgeRarity r) => switch (r) {
    BadgeRarity.common    => 'عادي',
    BadgeRarity.rare      => 'نادر',
    BadgeRarity.epic      => 'ملحمي',
    BadgeRarity.legendary => 'أسطوري',
  };

  @override
  Widget build(BuildContext context) {
    final theme    = Theme.of(context);
    final rc       = _rc(badge.rarity);
    final progress = isUnlocked
        ? 1.0
        : (totalXP / badge.xpRequired).clamp(0.0, 1.0);

    return Container(
      decoration: BoxDecoration(
        color: isUnlocked ? theme.colorScheme.surface : theme.colorScheme.surfaceContainerHighest.withOpacity(0.6),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isUnlocked ? rc.withOpacity(0.5) : theme.colorScheme.outline.withOpacity(0.1),
          width: isUnlocked ? 1.5 : 0.5)),
      padding: const EdgeInsets.all(14),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Stack(alignment: Alignment.bottomRight, children: [
          Text(badge.emoji,
            style: TextStyle(fontSize: 34,
                color: isUnlocked ? null : Colors.grey.withOpacity(0.5))),
          if (!isUnlocked)
            Container(padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                  color: theme.colorScheme.surfaceContainerHighest, shape: BoxShape.circle),
              child: Icon(Icons.lock, size: 12,
                  color: theme.colorScheme.onSurface.withOpacity(0.4))),
        ]),
        const SizedBox(height: 6),
        Text(badge.nameAr, textAlign: TextAlign.center,
            style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w700,
                color: isUnlocked ? null : theme.colorScheme.onSurface.withOpacity(0.4))),
        const SizedBox(height: 4),
        Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(color: rc.withOpacity(isUnlocked ? 0.12 : 0.06),
              borderRadius: BorderRadius.circular(10)),
          child: Text(_rl(badge.rarity),
              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                  color: rc.withOpacity(isUnlocked ? 1.0 : 0.4)))),
        const SizedBox(height: 8),
        ClipRRect(borderRadius: BorderRadius.circular(3),
          child: LinearProgressIndicator(value: progress, minHeight: 5,
            backgroundColor: theme.colorScheme.outline.withOpacity(0.1),
            valueColor: AlwaysStoppedAnimation(isUnlocked ? rc : rc.withOpacity(0.4)))),
        const SizedBox(height: 4),
        Text(isUnlocked ? '✓ مفتوح' : badge.condition,
            style: TextStyle(fontSize: 10,
                color: isUnlocked ? rc : theme.colorScheme.onSurface.withOpacity(0.5),
                fontWeight: isUnlocked ? FontWeight.w700 : FontWeight.w400)),
      ]),
    );
  }
}
