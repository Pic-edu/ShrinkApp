import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class QuickOptimizeButton extends StatelessWidget {
  final bool isOptimizing;
  final VoidCallback onTap;
  final String label;

  const QuickOptimizeButton({
    super.key,
    required this.isOptimizing,
    required this.onTap,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          color: isOptimizing ? const Color(0xFF1D9E75) : const Color(0xFF534AB7),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: isOptimizing ? null : onTap,
            borderRadius: BorderRadius.circular(18),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (isOptimizing)
                    const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                  else
                    const Text('⚡', style: TextStyle(fontSize: 20)),
                  const SizedBox(width: 10),
                  Text(label, style: const TextStyle(
                    fontFamily: 'Cairo', fontSize: 17,
                    fontWeight: FontWeight.w700, color: Colors.white)),
                ],
              ),
            ),
          ),
        ),
      ),
    ).animate().shimmer(
      duration: 2400.ms,
      color: Colors.white.withOpacity(0.15),
      delay: 1200.ms,
    );
  }
}
