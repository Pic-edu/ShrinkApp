import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

enum MascotMood { happy, neutral, sad, critical, optimizing }

class MascotWidget extends StatefulWidget {
  final double usedPercent;
  final bool isOptimizing;

  const MascotWidget({
    super.key,
    required this.usedPercent,
    this.isOptimizing = false,
  });

  @override
  State<MascotWidget> createState() => _MascotWidgetState();
}

class _MascotWidgetState extends State<MascotWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _blinkCtrl;

  @override
  void initState() {
    super.initState();
    _blinkCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 120));
    _scheduleBlink();
  }

  void _scheduleBlink() async {
    while (mounted) {
      await Future.delayed(const Duration(seconds: 4));
      if (!mounted) break;
      await _blinkCtrl.forward();
      await _blinkCtrl.reverse();
    }
  }

  @override
  void dispose() { _blinkCtrl.dispose(); super.dispose(); }

  MascotMood get _mood {
    if (widget.isOptimizing)            return MascotMood.optimizing;
    if (widget.usedPercent >= 0.90)     return MascotMood.critical;
    if (widget.usedPercent >= 0.70)     return MascotMood.sad;
    if (widget.usedPercent >= 0.45)     return MascotMood.neutral;
    return MascotMood.happy;
  }

  Color get _bodyColor => switch (_mood) {
    MascotMood.happy      => const Color(0xFFEEEDFE),
    MascotMood.neutral    => const Color(0xFFFAEEDA),
    MascotMood.sad        => const Color(0xFFE6F1FB),
    MascotMood.critical   => const Color(0xFFFCEBEB),
    MascotMood.optimizing => const Color(0xFFE1F5EE),
  };

  Color get _accentColor => switch (_mood) {
    MascotMood.happy      => const Color(0xFF7F77DD),
    MascotMood.neutral    => const Color(0xFFEF9F27),
    MascotMood.sad        => const Color(0xFF378ADD),
    MascotMood.critical   => const Color(0xFFE24B4A),
    MascotMood.optimizing => const Color(0xFF1D9E75),
  };

  String get _message => switch (_mood) {
    MascotMood.happy      => 'مساحتك ممتازة! 🎉',
    MascotMood.neutral    => 'يمكن تحسين مساحتك',
    MascotMood.sad        => 'أنا ممتلئ جداً 😩',
    MascotMood.critical   => 'تحذير: المساحة شبه ممتلئة!',
    MascotMood.optimizing => 'جارٍ التحسين... ✨',
  };

  String get _subMessage => switch (_mood) {
    MascotMood.happy      => 'استمر في الحفاظ على ترتيبك',
    MascotMood.neutral    => 'اضغط تحسين سريع لتحرير مساحة',
    MascotMood.sad        => 'الملفات الباردة تنتظرك',
    MascotMood.critical   => 'اضغط الآن لتحرير التخزين',
    MascotMood.optimizing => 'يُرجى الانتظار...',
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    Widget mascot = AnimatedBuilder(
      animation: _blinkCtrl,
      builder: (_, __) => CustomPaint(
        size: const Size(160, 160),
        painter: _MascotPainter(
          mood: _mood,
          bodyColor: _bodyColor,
          accentColor: _accentColor,
          blinkProgress: _blinkCtrl.value,
          usedPercent: widget.usedPercent,
        ),
      ),
    );

    mascot = switch (_mood) {
      MascotMood.happy => mascot
          .animate(onPlay: (c) => c.repeat(reverse: true))
          .moveY(begin: 0, end: -8, duration: 800.ms, curve: Curves.easeInOut),
      MascotMood.sad || MascotMood.critical => mascot
          .animate(onPlay: (c) => c.repeat(reverse: true))
          .rotate(begin: -0.05, end: 0.05, duration: 900.ms),
      _ => mascot,
    };

    return Column(
      children: [
        if (_mood == MascotMood.critical)
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                width: 180, height: 180,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _accentColor.withOpacity(0.4), width: 2),
                ),
              ).animate(onPlay: (c) => c.repeat())
                  .scaleXY(begin: 0.9, end: 1.2, duration: 1200.ms)
                  .fadeOut(begin: 0.6, duration: 1200.ms),
              mascot,
            ],
          )
        else
          mascot,
        const SizedBox(height: 12),
        Text(
          _message,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700, color: _accentColor),
          textAlign: TextAlign.center,
        ).animate().fadeIn(),
        const SizedBox(height: 4),
        Text(_subMessage,
            style: theme.textTheme.bodySmall, textAlign: TextAlign.center),
      ],
    );
  }
}

class _MascotPainter extends CustomPainter {
  final MascotMood mood;
  final Color bodyColor, accentColor;
  final double blinkProgress, usedPercent;

  _MascotPainter({
    required this.mood, required this.bodyColor, required this.accentColor,
    required this.blinkProgress, required this.usedPercent,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2 + 8;
    final r  = size.width * 0.36;

    final bodyPaint   = Paint()..color = bodyColor;
    final borderPaint = Paint()
      ..color = accentColor.withOpacity(0.4)
      ..style = PaintingStyle.stroke ..strokeWidth = 2;
    final darkPaint   = Paint()..color = const Color(0xFF26215C);
    final whitePaint  = Paint()..color = Colors.white;

    canvas.drawCircle(Offset(cx, cy), r, bodyPaint);
    canvas.drawCircle(Offset(cx, cy), r, borderPaint);

    final earPaint = Paint()..color = accentColor.withOpacity(0.5);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx - r + 4, cy - 14), width: 22, height: 28), earPaint);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx - r + 4, cy - 14), width: 11, height: 17), bodyPaint);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx + r - 4, cy - 14), width: 22, height: 28), earPaint);
    canvas.drawOval(Rect.fromCenter(center: Offset(cx + r - 4, cy - 14), width: 11, height: 17), bodyPaint);

    if (mood == MascotMood.happy || mood == MascotMood.optimizing) {
      final cheekPaint = Paint()..color = const Color(0xFFF4C0D1).withOpacity(0.7);
      canvas.drawOval(Rect.fromCenter(center: Offset(cx - 26, cy + 12), width: 22, height: 15), cheekPaint);
      canvas.drawOval(Rect.fromCenter(center: Offset(cx + 26, cy + 12), width: 22, height: 15), cheekPaint);
    }

    final eyeScaleY = 1.0 - blinkProgress;
    _drawEye(canvas, Offset(cx - 18, cy - 4), whitePaint, darkPaint, eyeScaleY);
    _drawEye(canvas, Offset(cx + 18, cy - 4), whitePaint, darkPaint, eyeScaleY);

    final mouthPaint = Paint()
      ..color = darkPaint.color ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5 ..strokeCap = StrokeCap.round;
    final path = Path();
    switch (mood) {
      case MascotMood.happy: case MascotMood.optimizing:
        path.moveTo(cx - 14, cy + 16);
        path.quadraticBezierTo(cx, cy + 28, cx + 14, cy + 16); break;
      case MascotMood.neutral:
        path.moveTo(cx - 12, cy + 18);
        path.quadraticBezierTo(cx, cy + 20, cx + 12, cy + 18); break;
      case MascotMood.sad: case MascotMood.critical:
        path.moveTo(cx - 14, cy + 24);
        path.quadraticBezierTo(cx, cy + 14, cx + 14, cy + 24); break;
    }
    canvas.drawPath(path, mouthPaint);

    if (mood == MascotMood.sad || mood == MascotMood.critical) {
      final sweatPaint = Paint()..color = const Color(0xFF85B7EB).withOpacity(0.8);
      canvas.drawOval(Rect.fromCenter(center: Offset(cx + r - 8, cy - 22), width: 10, height: 14), sweatPaint);
    }

    if (mood == MascotMood.critical) {
      final exclPaint = Paint()..color = const Color(0xFFE24B4A);
      canvas.drawRRect(RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(cx, cy - r - 12), width: 6, height: 14),
          const Radius.circular(3)), exclPaint);
      canvas.drawCircle(Offset(cx, cy - r + 8), 3, exclPaint);
    }

    if (mood == MascotMood.happy) {
      final crownPaint  = Paint()..color = const Color(0xFFEF9F27);
      final crownBorder = Paint()
        ..color = const Color(0xFFBA7517) ..style = PaintingStyle.stroke ..strokeWidth = 1.5;
      final crown = Path()
        ..moveTo(cx - 20, cy - r + 4) ..lineTo(cx - 12, cy - r - 14)
        ..lineTo(cx,      cy - r - 4)  ..lineTo(cx + 12, cy - r - 14)
        ..lineTo(cx + 20, cy - r + 4) ..close();
      canvas.drawPath(crown, crownPaint);
      canvas.drawPath(crown, crownBorder);
    }

    final barBg = Paint()..color = Colors.white.withOpacity(0.5);
    final barFill = Paint()..color = accentColor;
    const barW = 56.0; const barH = 9.0;
    final barX = cx - barW / 2;
    final barY = cy + r - 16;
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(barX, barY, barW, barH), const Radius.circular(4.5)), barBg);
    canvas.drawRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(barX, barY, barW * usedPercent.clamp(0.05, 1.0), barH),
        const Radius.circular(4.5)), barFill);
  }

  void _drawEye(Canvas canvas, Offset center, Paint white, Paint dark, double scaleY) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(1.0, scaleY.clamp(0.05, 1.0));
    canvas.drawOval(Rect.fromCenter(center: Offset.zero, width: 14, height: 16), white);
    final pupilY = (mood == MascotMood.sad || mood == MascotMood.critical) ? 3.0 : 2.0;
    canvas.drawCircle(Offset(0, pupilY), 5, dark);
    canvas.drawCircle(const Offset(2, -1), 1.5, white);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_MascotPainter old) =>
      old.mood != mood || old.blinkProgress != blinkProgress || old.usedPercent != usedPercent;
}
