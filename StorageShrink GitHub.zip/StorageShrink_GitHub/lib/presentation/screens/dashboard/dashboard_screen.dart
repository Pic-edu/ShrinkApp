import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:percent_indicator/percent_indicator.dart';

import '../../../core/services/permission_service.dart';
import '../../providers/storage_provider.dart';
import '../../providers/gamification_provider.dart';
import '../../providers/locale_provider.dart';
import '../../providers/scan_provider.dart';
import '../../../data/models/badge_model.dart';
import 'widgets/mascot_widget.dart';
import 'widgets/quick_optimize_button.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});
  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  bool _isOptimizing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkPermissions();
      _listenForNewBadge();
    });
  }

  Future<void> _checkPermissions() async {
    final has = await PermissionService().hasStoragePermission();
    if (!has && mounted) _showPermissionDialog();
    else ref.read(storageStatsProvider.notifier).refresh();
  }

  void _listenForNewBadge() {
    ref.listen(gamificationProvider, (_, next) {
      if (next.newlyUnlockedBadgeId != null && mounted) {
        final badge = BadgeModel.all.firstWhere(
            (b) => b.id == next.newlyUnlockedBadgeId);
        _showBadgeToast(badge);
        ref.read(gamificationProvider.notifier).clearNewBadge();
      }
    });
  }

  void _showBadgeToast(BadgeModel badge) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: const Color(0xFF534AB7),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      content: Row(children: [
        Text(badge.emoji, style: const TextStyle(fontSize: 24)),
        const SizedBox(width: 10),
        Expanded(child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('شارة جديدة مفتوحة! 🎉',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
            Text(badge.nameAr,
                style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12)),
          ],
        )),
      ]),
      duration: const Duration(seconds: 3),
    ));
  }

  void _showPermissionDialog() {
    final l10n = AppLocalizations.of(context)!;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text(l10n.permissionRequired),
        content: Text(l10n.permissionMessage),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text(l10n.cancel),
          ),
          FilledButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final result = await PermissionService().requestStoragePermission();
              if (result == PermissionResult.permanentlyDenied && mounted) {
                PermissionService().openSettings();
              } else if (result == PermissionResult.granted) {
                ref.read(storageStatsProvider.notifier).refresh();
              }
            },
            child: Text(l10n.grantPermission),
          ),
        ],
      ),
    );
  }

  Future<void> _onQuickOptimize() async {
    setState(() => _isOptimizing = true);
    ref.invalidate(scanStreamProvider);
    await ref.read(scanStreamProvider.future);
    ref.read(gamificationProvider.notifier).addXP(50);
    if (mounted) {
      setState(() => _isOptimizing = false);
      context.push('/categories');
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n   = AppLocalizations.of(context)!;
    final stats  = ref.watch(storageStatsProvider);
    final gamif  = ref.watch(gamificationProvider);
    final locale = ref.watch(localeProvider);
    final isAr   = locale?.languageCode == 'ar';
    final theme  = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true,
              backgroundColor: Colors.transparent,
              elevation: 0,
              title: Text(l10n.appName,
                  style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              actions: [
                IconButton(
                  tooltip: l10n.language,
                  icon: Text(isAr ? 'EN' : 'ع',
                      style: theme.textTheme.labelLarge?.copyWith(
                          fontWeight: FontWeight.bold, color: theme.colorScheme.primary)),
                  onPressed: () => ref.read(localeProvider.notifier).toggle(),
                ),
                IconButton(
                  icon: const Icon(Icons.emoji_events_outlined),
                  onPressed: () => context.push('/badges'),
                ),
                const SizedBox(width: 4),
              ],
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  const SizedBox(height: 8),
                  _XPRow(xp: gamif.totalXP, l10n: l10n)
                      .animate().fadeIn(delay: 100.ms).slideX(begin: 0.3),
                  const SizedBox(height: 24),
                  Center(child: MascotWidget(
                    usedPercent: stats.usedPercent,
                    isOptimizing: _isOptimizing,
                  ).animate().scale(begin: const Offset(0.7, 0.7),
                      duration: 600.ms, curve: Curves.elasticOut)),
                  const SizedBox(height: 28),
                  Center(child: _StorageGauge(stats: stats, l10n: l10n)
                      .animate().fadeIn(delay: 200.ms)),
                  const SizedBox(height: 32),
                  QuickOptimizeButton(
                    isOptimizing: _isOptimizing,
                    onTap: _onQuickOptimize,
                    label: _isOptimizing ? l10n.optimizing : l10n.quickOptimize,
                  ).animate().fadeIn(delay: 300.ms).slideY(begin: 0.5),
                  const SizedBox(height: 24),
                  _CategoriesGrid(l10n: l10n)
                      .animate().fadeIn(delay: 400.ms).slideY(begin: 0.3),
                  const SizedBox(height: 32),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _XPRow extends StatelessWidget {
  final int xp; final AppLocalizations l10n;
  const _XPRow({required this.xp, required this.l10n});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withOpacity(0.4),
        borderRadius: BorderRadius.circular(50),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        const Text('⭐', style: TextStyle(fontSize: 16)),
        const SizedBox(width: 6),
        Text(l10n.xpEarned(xp.toString()),
            style: theme.textTheme.labelLarge?.copyWith(
                color: theme.colorScheme.primary, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _StorageGauge extends StatelessWidget {
  final StorageStats stats; final AppLocalizations l10n;
  const _StorageGauge({required this.stats, required this.l10n});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = stats.usedPercent > 0.85 ? Colors.red
        : stats.usedPercent > 0.6 ? Colors.orange : Colors.green;
    return CircularPercentIndicator(
      radius: 110.0, lineWidth: 14.0,
      animation: true, animationDuration: 1200,
      percent: stats.usedPercent.clamp(0.0, 1.0),
      center: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('${(stats.usedPercent * 100).toInt()}%',
            style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text(l10n.storageUsed(stats.usedFormatted), style: theme.textTheme.bodySmall),
        Text(l10n.storageFree(stats.freeFormatted),
            style: theme.textTheme.bodySmall?.copyWith(color: Colors.green)),
      ]),
      progressColor: color,
      backgroundColor: theme.colorScheme.surfaceVariant,
      circularStrokeCap: CircularStrokeCap.round,
    );
  }
}

class _CategoriesGrid extends StatelessWidget {
  final AppLocalizations l10n;
  const _CategoriesGrid({required this.l10n});
  @override
  Widget build(BuildContext context) {
    final cats = [
      (emoji: '🖼️', label: l10n.imagesVideos,  route: '/gallery'),
      (emoji: '📄', label: l10n.filesDocuments, route: '/categories'),
      (emoji: '🗑️', label: l10n.smartTrash,     route: '/trash'),
      (emoji: '🏅', label: 'الإنجازات',          route: '/badges'),
    ];
    return GridView.count(
      crossAxisCount: 2, shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.4,
      children: cats.map((c) => _CategoryCard(
        emoji: c.emoji, label: c.label, route: c.route)).toList(),
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final String emoji, label, route;
  const _CategoryCard({required this.emoji, required this.label, required this.route});
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InkWell(
      onTap: () => context.push(route),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceVariant,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.colorScheme.outline.withOpacity(0.2)),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(height: 8),
          Text(label, textAlign: TextAlign.center,
              style: theme.textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}
