import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/services/storage_scanner_service.dart';
import '../../data/models/file_item.dart';

final scanStreamProvider = StreamProvider.autoDispose<ScanResult>((ref) {
  return StorageScannerService().scan();
});

final latestScanProvider = Provider.autoDispose<ScanResult?>((ref) {
  return ref.watch(scanStreamProvider).whenData((r) => r).valueOrNull;
});

enum ScanFilter { all, cold30, cold60, large }

final scanFilterProvider = StateProvider<ScanFilter>((_) => ScanFilter.all);

final filteredFilesProvider = Provider.autoDispose<List<FileItem>>((ref) {
  final result = ref.watch(latestScanProvider);
  final filter = ref.watch(scanFilterProvider);
  if (result == null) return [];
  switch (filter) {
    case ScanFilter.all:   return result.allFiles;
    case ScanFilter.cold30:
      return result.coldFiles
          .where((f) => f.coldStatus == ColdStatus.cold30).toList();
    case ScanFilter.cold60:
      return result.coldFiles
          .where((f) => f.coldStatus == ColdStatus.cold60).toList();
    case ScanFilter.large: return result.largeFiles;
  }
});

final selectedFilesProvider =
    StateNotifierProvider<SelectedFilesNotifier, Set<String>>(
  (_) => SelectedFilesNotifier(),
);

class SelectedFilesNotifier extends StateNotifier<Set<String>> {
  SelectedFilesNotifier() : super({});
  void toggle(String id)            => state.contains(id)
      ? state = {...state}..remove(id)
      : state = {...state, id};
  void selectAll(List<FileItem> f)  => state = f.map((x) => x.id).toSet();
  void clearAll()                   => state = {};
}
