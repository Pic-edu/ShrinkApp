import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/models/badge_model.dart';

class GamificationState {
  final int totalXP;
  final List<String> unlockedBadges;
  final String? newlyUnlockedBadgeId;

  const GamificationState({
    this.totalXP = 0,
    this.unlockedBadges = const [],
    this.newlyUnlockedBadgeId,
  });
}

class GamificationNotifier extends StateNotifier<GamificationState> {
  GamificationNotifier() : super(const GamificationState()) { _load(); }

  Future<void> _load() async {
    final prefs  = await SharedPreferences.getInstance();
    final xp     = prefs.getInt('total_xp') ?? 0;
    final badges = prefs.getStringList('badges') ?? [];
    state = GamificationState(totalXP: xp, unlockedBadges: badges);
  }

  Future<void> addXP(int amount) async {
    if (amount <= 0) return;
    final newXP  = state.totalXP + amount;
    final badges = List<String>.from(state.unlockedBadges);
    String? newBadge;

    for (final badge in BadgeModel.all) {
      if (!badges.contains(badge.id) && newXP >= badge.xpRequired) {
        badges.add(badge.id);
        newBadge = badge.id;
      }
    }

    state = GamificationState(
      totalXP: newXP,
      unlockedBadges: badges,
      newlyUnlockedBadgeId: newBadge,
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('total_xp', newXP);
    await prefs.setStringList('badges', badges);
  }

  void clearNewBadge() => state = GamificationState(
    totalXP: state.totalXP,
    unlockedBadges: state.unlockedBadges,
  );
}

final gamificationProvider =
    StateNotifierProvider<GamificationNotifier, GamificationState>(
  (_) => GamificationNotifier(),
);
