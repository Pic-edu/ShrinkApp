import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:disk_space_plus/disk_space_plus.dart';

class StorageStats {
  final double usedBytes;
  final double totalBytes;
  const StorageStats({this.usedBytes = 0, this.totalBytes = 1});

  double get usedPercent  => usedBytes / totalBytes;
  double get freeBytes    => totalBytes - usedBytes;
  String get usedFormatted  => _fmt(usedBytes);
  String get freeFormatted  => _fmt(freeBytes);
  String get totalFormatted => _fmt(totalBytes);

  String _fmt(double b) {
    if (b >= 1e9) return '${(b / 1e9).toStringAsFixed(1)} GB';
    if (b >= 1e6) return '${(b / 1e6).toStringAsFixed(0)} MB';
    return '${(b / 1e3).toStringAsFixed(0)} KB';
  }
}

class StorageStatsNotifier extends StateNotifier<StorageStats> {
  StorageStatsNotifier() : super(const StorageStats()) { refresh(); }

  Future<void> refresh() async {
    try {
      final freeMB  = await DiskSpacePlus.getFreeDiskSpace  ?? 0;
      final totalMB = await DiskSpacePlus.getTotalDiskSpace ?? 1;
      state = StorageStats(
        usedBytes:  (totalMB - freeMB) * 1e6,
        totalBytes: totalMB * 1e6,
      );
    } catch (_) {}
  }
}

final storageStatsProvider =
    StateNotifierProvider<StorageStatsNotifier, StorageStats>(
  (_) => StorageStatsNotifier(),
);
