import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../core/services/compression_service.dart';
import '../../data/models/file_item.dart';
import '../../data/models/compression_result.dart';
import 'scan_provider.dart';
import 'gamification_provider.dart';

final compressionSettingsProvider =
    StateProvider<CompressionSettings>((_) => const CompressionSettings());

class CompressionBatchNotifier
    extends StateNotifier<AsyncValue<CompressionBatchResult?>> {
  final Ref _ref;
  StreamSubscription<CompressionResult>? _sub;

  CompressionBatchNotifier(this._ref) : super(const AsyncValue.data(null));

  Future<void> startBatch(List<FileItem> files) async {
    if (files.isEmpty) return;
    state = const AsyncValue.loading();
    final settings  = _ref.read(compressionSettingsProvider);
    final results   = <CompressionResult>[];
    final stopwatch = Stopwatch()..start();

    _sub = CompressionService().compressBatch(files, settings).listen(
      (result) {
        results.add(result);
        state = AsyncValue.data(CompressionBatchResult(
          results: List.from(results), elapsed: stopwatch.elapsed));
      },
      onDone: () {
        stopwatch.stop();
        final batch = CompressionBatchResult(
            results: List.from(results), elapsed: stopwatch.elapsed);
        state = AsyncValue.data(batch);
        final savedMB = batch.totalSavedBytes ~/ (1024 * 1024);
        if (savedMB > 0) _ref.read(gamificationProvider.notifier).addXP(savedMB);
        _persistLog(batch);
        _ref.invalidate(scanStreamProvider);
      },
      onError: (e) => state = AsyncValue.error(e, StackTrace.current),
    );
  }

  void cancel() { _sub?.cancel(); state = const AsyncValue.data(null); }

  Future<void> _persistLog(CompressionBatchResult batch) async {
    final box = await Hive.openBox<String>('compression_log');
    await box.add({
      'date': DateTime.now().toIso8601String(),
      'saved_bytes': batch.totalSavedBytes,
      'file_count': batch.successCount,
    }.toString());
  }

  @override
  void dispose() { _sub?.cancel(); super.dispose(); }
}

final compressionBatchProvider = StateNotifierProvider.autoDispose<
    CompressionBatchNotifier, AsyncValue<CompressionBatchResult?>>(
  (ref) => CompressionBatchNotifier(ref),
);
