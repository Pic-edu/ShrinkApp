import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/services/trash_manager_service.dart';
import '../../core/services/notification_service.dart';
import '../../data/models/file_item.dart';
import '../../data/models/trash_item.dart';
import 'gamification_provider.dart';
import 'scan_provider.dart';

final trashSizeProvider = FutureProvider.autoDispose<int>(
  (_) => TrashManagerService().totalSizeBytes(),
);

class TrashNotifier extends StateNotifier<AsyncValue<List<TrashItem>>> {
  final Ref _ref;
  TrashNotifier(this._ref) : super(const AsyncValue.loading()) { _load(); }

  Future<void> _load() async {
    state = const AsyncValue.loading();
    try {
      state = AsyncValue.data(await TrashManagerService().getAll());
    } catch (e, s) { state = AsyncValue.error(e, s); }
  }

  Future<void> sendToTrash(List<FileItem> files) async {
    final items = await TrashManagerService().moveMultipleToTrash(files);
    for (final item in items) {
      await NotificationService().scheduleTrashExpiry(
        id: item.id.hashCode,
        fileName: item.name,
        expiresAt: item.expiresAt,
      );
    }
    _ref.read(gamificationProvider.notifier).addXP(files.length * 5);
    await _load();
  }

  Future<bool> restore(String itemId) async {
    final ok = await TrashManagerService().restore(itemId);
    await _load();
    _ref.invalidate(scanStreamProvider);
    return ok;
  }

  Future<void> permanentlyDelete(String itemId) async {
    await TrashManagerService().permanentlyDelete(itemId);
    NotificationService().cancel(itemId.hashCode);
    await _load();
  }

  Future<int> emptyTrash() async {
    final count = await TrashManagerService().emptyTrash();
    state = const AsyncValue.data([]);
    return count;
  }

  Future<int> purgeExpired() async {
    final count = await TrashManagerService().purgeExpired();
    await _load();
    return count;
  }
}

final trashProvider = StateNotifierProvider.autoDispose<
    TrashNotifier, AsyncValue<List<TrashItem>>>(
  (ref) => TrashNotifier(ref),
);
