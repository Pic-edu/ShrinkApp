import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../core/services/ml_classifier_service.dart';
import '../../data/models/file_item.dart';
import '../../data/models/screenshot_category.dart';
import 'scan_provider.dart';
import 'gamification_provider.dart';

class ClassificationNotifier
    extends StateNotifier<AsyncValue<ClassificationBatch?>> {
  final Ref _ref;
  ClassificationNotifier(this._ref) : super(const AsyncValue.data(null));

  Future<void> classifyScreenshots() async {
    final scan = _ref.read(latestScanProvider);
    if (scan == null) return;
    final screenshots =
        scan.allFiles.where((f) => f.type == FileType.image).toList();
    if (screenshots.isEmpty) return;

    state = const AsyncValue.loading();
    final results = <ClassificationResult>[];

    await for (final batch
        in MLClassifierService().classifyBatch(screenshots)) {
      results
        ..clear()
        ..addAll(batch.results);
      state = AsyncValue.data(batch);
      _persistCache(batch.results);
    }

    _ref.read(gamificationProvider.notifier).addXP(results.length * 2);
  }

  Future<void> _persistCache(List<ClassificationResult> results) async {
    final box = await Hive.openBox<String>('classification_cache');
    for (final r in results) await box.put(r.fileId, r.category.name);
  }

  Future<void> correctCategory(
      String fileId, ScreenshotCategory newCategory) async {
    final current = state.valueOrNull;
    if (current == null) return;
    final updated = current.results.map((r) {
      if (r.fileId != fileId) return r;
      return ClassificationResult(
        fileId: r.fileId, filePath: r.filePath,
        category: newCategory, confidence: 1.0,
        detectedLabels: r.detectedLabels,
        extractedText: r.extractedText,
        hasQrCode: r.hasQrCode, qrData: r.qrData,
        suggestedContact: r.suggestedContact,
      );
    }).toList();
    state = AsyncValue.data(ClassificationBatch(
      results: updated,
      isComplete: current.isComplete,
      progressPercent: current.progressPercent,
    ));
    final box = await Hive.openBox<String>('classification_cache');
    await box.put(fileId, newCategory.name);
  }
}

final classificationProvider = StateNotifierProvider.autoDispose<
    ClassificationNotifier, AsyncValue<ClassificationBatch?>>(
  (ref) => ClassificationNotifier(ref),
);

final selectedCategoryProvider = StateProvider<ScreenshotCategory?>((_) => null);

final filteredScreenshotsProvider =
    Provider.autoDispose<List<ClassificationResult>>((ref) {
  final batch    = ref.watch(classificationProvider).valueOrNull;
  final selected = ref.watch(selectedCategoryProvider);
  if (batch == null) return [];
  if (selected == null) return batch.results;
  return batch.forCategory(selected);
});
