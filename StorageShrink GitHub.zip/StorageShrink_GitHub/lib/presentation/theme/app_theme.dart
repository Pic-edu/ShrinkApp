import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class AppTheme {
  static const _primary      = Color(0xFF534AB7);
  static const _primaryLight = Color(0xFFEEEDFE);
  static const _secondary    = Color(0xFF1D9E75);
  static const _tertiary     = Color(0xFFBA7517);
  static const _error        = Color(0xFFE24B4A);

  static ThemeData get light => _build(Brightness.light);
  static ThemeData get dark  => _build(Brightness.dark);

  static ThemeData _build(Brightness brightness) {
    final isDark = brightness == Brightness.dark;
    final colorScheme = ColorScheme.fromSeed(
      seedColor: _primary,
      brightness: brightness,
      primary: _primary,
      secondary: _secondary,
      tertiary: _tertiary,
      error: _error,
      surface: isDark ? const Color(0xFF1A1A2E) : const Color(0xFFFAFAFD),
      surfaceContainerHighest: isDark
          ? const Color(0xFF2A2A40)
          : const Color(0xFFF1EFE8),
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      fontFamily: 'Cairo',
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        systemOverlayStyle: isDark
            ? SystemUiOverlayStyle.light
            : SystemUiOverlayStyle.dark,
        titleTextStyle: TextStyle(
          fontFamily: 'Cairo',
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: colorScheme.onSurface,
        ),
        iconTheme: IconThemeData(color: colorScheme.onSurface),
      ),
      textTheme: _buildTextTheme(colorScheme),
      cardTheme: CardTheme(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: colorScheme.outline.withOpacity(0.15),
            width: 0.5,
          ),
        ),
        color: isDark ? const Color(0xFF242438) : Colors.white,
      ),
      chipTheme: ChipThemeData(
        backgroundColor: colorScheme.surfaceContainerHighest,
        selectedColor: colorScheme.primaryContainer,
        labelStyle: const TextStyle(
          fontFamily: 'Cairo',
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        side: BorderSide.none,
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: _primary,
          foregroundColor: Colors.white,
          textStyle: const TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.w700,
            fontSize: 15,
          ),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: colorScheme.surface,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        elevation: 0,
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: _primary,
        linearTrackColor: _primaryLight,
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: _primary,
        thumbColor: _primary,
        overlayColor: _primary.withOpacity(0.15),
        inactiveTrackColor: _primaryLight,
        trackHeight: 4,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? _primary : null,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (s) => s.contains(WidgetState.selected) ? _primaryLight : null,
        ),
      ),
    );
  }

  static TextTheme _buildTextTheme(ColorScheme cs) => TextTheme(
        displayLarge:   _t(32, FontWeight.w700, cs.onSurface),
        headlineMedium: _t(22, FontWeight.w700, cs.onSurface),
        headlineSmall:  _t(20, FontWeight.w700, cs.onSurface),
        titleLarge:     _t(18, FontWeight.w700, cs.onSurface),
        titleMedium:    _t(16, FontWeight.w600, cs.onSurface),
        titleSmall:     _t(14, FontWeight.w600, cs.onSurface),
        bodyLarge:      _t(16, FontWeight.w400, cs.onSurface),
        bodyMedium:     _t(14, FontWeight.w400, cs.onSurface),
        bodySmall:      _t(12, FontWeight.w400, cs.onSurface.withOpacity(0.65)),
        labelLarge:     _t(14, FontWeight.w600, cs.onSurface),
        labelMedium:    _t(12, FontWeight.w600, cs.onSurface),
        labelSmall:     _t(11, FontWeight.w500, cs.onSurface.withOpacity(0.6)),
      );

  static TextStyle _t(double size, FontWeight w, Color c) => TextStyle(
        fontFamily: 'Cairo',
        fontSize: size,
        fontWeight: w,
        color: c,
        height: 1.5,
      );
}
