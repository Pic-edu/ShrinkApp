import 'file_item.dart';

enum CompressionStatus { pending, compressing, done, failed, skipped }
enum CompressionMethod { zip, lzma, webp, heic, h265 }

class CompressionResult {
  final String fileId;
  final String originalPath;
  final String? compressedPath;
  final int originalSizeBytes;
  final int compressedSizeBytes;
  final CompressionStatus status;
  final CompressionMethod method;
  final String? errorMessage;
  final DateTime timestamp;

  const CompressionResult({
    required this.fileId,
    required this.originalPath,
    this.compressedPath,
    required this.originalSizeBytes,
    this.compressedSizeBytes = 0,
    required this.status,
    required this.method,
    this.errorMessage,
    required this.timestamp,
  });

  int get savedBytes => status == CompressionStatus.done
      ? (originalSizeBytes - compressedSizeBytes).clamp(0, originalSizeBytes)
      : 0;

  double get compressionRatio => originalSizeBytes > 0
      ? 1.0 - (compressedSizeBytes / originalSizeBytes)
      : 0.0;

  String get savedFormatted {
    final b = savedBytes;
    if (b >= 1024 * 1024) return '${(b / (1024 * 1024)).toStringAsFixed(1)} MB';
    if (b >= 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
    return '$b B';
  }
}

class CompressionBatchResult {
  final List<CompressionResult> results;
  final Duration elapsed;

  const CompressionBatchResult({required this.results, required this.elapsed});

  int get totalSavedBytes => results.fold(0, (s, r) => s + r.savedBytes);
  int get successCount =>
      results.where((r) => r.status == CompressionStatus.done).length;
  int get failedCount =>
      results.where((r) => r.status == CompressionStatus.failed).length;

  String get totalSavedFormatted {
    final b = totalSavedBytes;
    if (b >= 1024 * 1024 * 1024) {
      return '${(b / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
    }
    if (b >= 1024 * 1024) return '${(b / (1024 * 1024)).toStringAsFixed(1)} MB';
    if (b >= 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
    return '$b B';
  }
}
