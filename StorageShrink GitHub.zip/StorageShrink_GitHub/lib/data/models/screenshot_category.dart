enum ScreenshotCategory {
  movie,
  chat,
  web,
  social,
  receipt,
  meme,
  uncategorized
}

extension ScreenshotCategoryX on ScreenshotCategory {
  String get labelAr => const {
        ScreenshotCategory.movie:         'أفلام ومسلسلات',
        ScreenshotCategory.chat:          'محادثات',
        ScreenshotCategory.web:           'مواقع وأرشيف',
        ScreenshotCategory.social:        'سوشيال ميديا',
        ScreenshotCategory.receipt:       'إيصالات و QR',
        ScreenshotCategory.meme:          'ميمز',
        ScreenshotCategory.uncategorized: 'غير مصنَّف',
      }[this]!;

  String get labelEn => const {
        ScreenshotCategory.movie:         'Movies & Series',
        ScreenshotCategory.chat:          'Chats',
        ScreenshotCategory.web:           'Web & Articles',
        ScreenshotCategory.social:        'Social / Reels',
        ScreenshotCategory.receipt:       'Receipts & QR',
        ScreenshotCategory.meme:          'Memes',
        ScreenshotCategory.uncategorized: 'Uncategorized',
      }[this]!;

  String get emoji => const {
        ScreenshotCategory.movie:         '🎬',
        ScreenshotCategory.chat:          '💬',
        ScreenshotCategory.web:           '🌐',
        ScreenshotCategory.social:        '📱',
        ScreenshotCategory.receipt:       '🎟️',
        ScreenshotCategory.meme:          '😂',
        ScreenshotCategory.uncategorized: '📂',
      }[this]!;
}

class ClassificationResult {
  final String fileId;
  final String filePath;
  final ScreenshotCategory category;
  final double confidence;
  final List<String> detectedLabels;
  final String? extractedText;
  final bool hasQrCode;
  final String? qrData;
  final String? suggestedContact;

  const ClassificationResult({
    required this.fileId,
    required this.filePath,
    required this.category,
    required this.confidence,
    this.detectedLabels = const [],
    this.extractedText,
    this.hasQrCode = false,
    this.qrData,
    this.suggestedContact,
  });

  bool get isHighConfidence => confidence >= 0.70;
}

class ClassificationBatch {
  final List<ClassificationResult> results;
  final bool isComplete;
  final double progressPercent;

  const ClassificationBatch({
    this.results = const [],
    this.isComplete = false,
    this.progressPercent = 0,
  });

  Map<ScreenshotCategory, List<ClassificationResult>> get grouped {
    final map = <ScreenshotCategory, List<ClassificationResult>>{};
    for (final r in results) {
      map.putIfAbsent(r.category, () => []).add(r);
    }
    return map;
  }

  List<ClassificationResult> forCategory(ScreenshotCategory cat) =>
      grouped[cat] ?? [];
}
