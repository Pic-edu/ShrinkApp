enum BadgeRarity { common, rare, epic, legendary }

class BadgeModel {
  final String id;
  final String emoji;
  final String nameAr;
  final String nameEn;
  final String descriptionAr;
  final String descriptionEn;
  final int xpRequired;
  final BadgeRarity rarity;
  final String condition;

  const BadgeModel({
    required this.id,
    required this.emoji,
    required this.nameAr,
    required this.nameEn,
    required this.descriptionAr,
    required this.descriptionEn,
    required this.xpRequired,
    required this.rarity,
    required this.condition,
  });

  static const List<BadgeModel> all = [
    BadgeModel(
      id: 'first_compress', emoji: '🗜️',
      nameAr: 'أول ضغطة', nameEn: 'First Squeeze',
      descriptionAr: 'قمت بضغط ملفاتك للمرة الأولى',
      descriptionEn: 'Compressed your files for the first time',
      xpRequired: 10, rarity: BadgeRarity.common, condition: '10 XP',
    ),
    BadgeModel(
      id: 'space_saver', emoji: '💾',
      nameAr: 'موفّر المساحة', nameEn: 'Space Saver',
      descriptionAr: 'وفّرت أكثر من 100 MB',
      descriptionEn: 'Saved more than 100 MB',
      xpRequired: 100, rarity: BadgeRarity.common, condition: '100 XP',
    ),
    BadgeModel(
      id: 'photo_organizer', emoji: '📸',
      nameAr: 'منظّم الصور', nameEn: 'Photo Organizer',
      descriptionAr: 'صنّفت أكثر من 50 لقطة شاشة',
      descriptionEn: 'Classified over 50 screenshots',
      xpRequired: 300, rarity: BadgeRarity.rare, condition: '300 XP',
    ),
    BadgeModel(
      id: 'cold_hunter', emoji: '❄️',
      nameAr: 'صيّاد البرد', nameEn: 'Cold Hunter',
      descriptionAr: 'كشفت عن 100 ملف بارد',
      descriptionEn: 'Found 100 cold files',
      xpRequired: 500, rarity: BadgeRarity.rare, condition: '500 XP',
    ),
    BadgeModel(
      id: 'gb_saver', emoji: '🚀',
      nameAr: 'موفّر الجيجابايت', nameEn: 'GB Saver',
      descriptionAr: 'وفّرت أكثر من 1 GB',
      descriptionEn: 'Saved over 1 GB',
      xpRequired: 1000, rarity: BadgeRarity.epic, condition: '1000 XP',
    ),
    BadgeModel(
      id: 'ai_master', emoji: '🤖',
      nameAr: 'سيّد الذكاء', nameEn: 'AI Master',
      descriptionAr: 'صنّفت أكثر من 500 صورة بالذكاء الاصطناعي',
      descriptionEn: 'Classified 500+ images with AI',
      xpRequired: 2000, rarity: BadgeRarity.epic, condition: '2000 XP',
    ),
    BadgeModel(
      id: 'storage_legend', emoji: '👑',
      nameAr: 'أسطورة التخزين', nameEn: 'Storage Legend',
      descriptionAr: 'وفّرت أكثر من 10 GB إجمالاً',
      descriptionEn: 'Saved over 10 GB total',
      xpRequired: 5000, rarity: BadgeRarity.legendary, condition: '5000 XP',
    ),
  ];
}
