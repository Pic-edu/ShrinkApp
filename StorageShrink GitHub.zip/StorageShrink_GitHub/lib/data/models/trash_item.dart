import 'file_item.dart';

enum TrashItemState { pending, expiringSoon, expired }

class TrashItem {
  final String id;
  final String originalPath;
  final String? compressedPath;
  final String name;
  final int sizeBytes;
  final FileType fileType;
  final DateTime deletedAt;
  final DateTime expiresAt;
  final String? thumbnailPath;

  const TrashItem({
    required this.id,
    required this.originalPath,
    this.compressedPath,
    required this.name,
    required this.sizeBytes,
    required this.fileType,
    required this.deletedAt,
    required this.expiresAt,
    this.thumbnailPath,
  });

  TrashItemState get state {
    final now = DateTime.now();
    if (now.isAfter(expiresAt)) return TrashItemState.expired;
    if (expiresAt.difference(now).inDays <= 2) return TrashItemState.expiringSoon;
    return TrashItemState.pending;
  }

  int get daysRemaining =>
      expiresAt.difference(DateTime.now()).inDays.clamp(0, 14);

  String get sizeFormatted {
    if (sizeBytes >= 1024 * 1024) {
      return '${(sizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    if (sizeBytes >= 1024) return '${(sizeBytes / 1024).toStringAsFixed(0)} KB';
    return '$sizeBytes B';
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'originalPath': originalPath,
        'compressedPath': compressedPath,
        'name': name,
        'sizeBytes': sizeBytes,
        'fileType': fileType.name,
        'deletedAt': deletedAt.toIso8601String(),
        'expiresAt': expiresAt.toIso8601String(),
        'thumbnailPath': thumbnailPath,
      };

  factory TrashItem.fromMap(Map<String, dynamic> m) => TrashItem(
        id: m['id'] as String,
        originalPath: m['originalPath'] as String,
        compressedPath: m['compressedPath'] as String?,
        name: m['name'] as String,
        sizeBytes: m['sizeBytes'] as int,
        fileType: FileType.values.firstWhere(
          (t) => t.name == m['fileType'],
          orElse: () => FileType.other,
        ),
        deletedAt: DateTime.parse(m['deletedAt'] as String),
        expiresAt: DateTime.parse(m['expiresAt'] as String),
        thumbnailPath: m['thumbnailPath'] as String?,
      );

  factory TrashItem.fromFileItem(FileItem file) => TrashItem(
        id: file.id,
        originalPath: file.path,
        name: file.name,
        sizeBytes: file.sizeBytes,
        fileType: file.type,
        deletedAt: DateTime.now(),
        expiresAt: DateTime.now().add(const Duration(days: 14)),
      );
}
