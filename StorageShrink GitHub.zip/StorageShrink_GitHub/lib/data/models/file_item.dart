import 'package:photo_manager/photo_manager.dart';

enum FileType { image, video, document, audio, apk, other }
enum ColdStatus { warm, cold30, cold60 }

class FileItem {
  final String id;
  final String name;
  final String path;
  final int sizeBytes;
  final DateTime lastModified;
  final DateTime? lastAccessed;
  final FileType type;
  final ColdStatus coldStatus;
  final AssetEntity? photoAsset;

  const FileItem({
    required this.id,
    required this.name,
    required this.path,
    required this.sizeBytes,
    required this.lastModified,
    this.lastAccessed,
    required this.type,
    required this.coldStatus,
    this.photoAsset,
  });

  String get sizeFormatted {
    if (sizeBytes >= 1024 * 1024 * 1024) {
      return '${(sizeBytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    } else if (sizeBytes >= 1024 * 1024) {
      return '${(sizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    } else if (sizeBytes >= 1024) {
      return '${(sizeBytes / 1024).toStringAsFixed(0)} KB';
    }
    return '$sizeBytes B';
  }

  bool get isCold =>
      coldStatus == ColdStatus.cold30 || coldStatus == ColdStatus.cold60;

  String get extension =>
      name.contains('.') ? name.split('.').last.toLowerCase() : '';
}

class ScanResult {
  final List<FileItem> allFiles;
  final List<FileItem> coldFiles;
  final List<FileItem> largeFiles;
  final int scannedCount;
  final bool isComplete;
  final double progressPercent;

  const ScanResult({
    this.allFiles = const [],
    this.coldFiles = const [],
    this.largeFiles = const [],
    this.scannedCount = 0,
    this.isComplete = false,
    this.progressPercent = 0,
  });

  int get totalSizeBytes => allFiles.fold(0, (s, f) => s + f.sizeBytes);
  int get coldSizeBytes  => coldFiles.fold(0, (s, f) => s + f.sizeBytes);

  Map<FileType, List<FileItem>> get grouped {
    final map = <FileType, List<FileItem>>{};
    for (final f in allFiles) {
      map.putIfAbsent(f.type, () => []).add(f);
    }
    return map;
  }
}
