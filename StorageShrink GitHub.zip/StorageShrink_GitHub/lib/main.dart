import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'app.dart';
import 'core/services/notification_service.dart';
import 'core/services/background_worker_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Hive.initFlutter();

  await NotificationService().init();
  await NotificationService().requestPermission();
  await NotificationService().scheduleWeeklyReport();

  await BackgroundWorkerService().init();
  await BackgroundWorkerService().registerPurgeTask();
  await BackgroundWorkerService().registerWeeklyReport();

  runApp(const ProviderScope(child: StorageShrinkApp()));
}
