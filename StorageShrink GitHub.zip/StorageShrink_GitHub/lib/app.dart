import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import 'presentation/providers/locale_provider.dart';
import 'presentation/screens/dashboard/dashboard_screen.dart';
import 'presentation/screens/categories/categories_screen.dart';
import 'presentation/screens/gallery/smart_gallery_screen.dart';
import 'presentation/screens/trash/smart_trash_screen.dart';
import 'presentation/screens/badges/badges_screen.dart';
import 'presentation/theme/app_theme.dart';

final _router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/',           builder: (_, __) => const DashboardScreen()),
    GoRoute(path: '/categories', builder: (_, __) => const CategoriesScreen()),
    GoRoute(path: '/gallery',    builder: (_, __) => const SmartGalleryScreen()),
    GoRoute(path: '/trash',      builder: (_, __) => const SmartTrashScreen()),
    GoRoute(path: '/badges',     builder: (_, __) => const BadgesScreen()),
  ],
);

class StorageShrinkApp extends ConsumerWidget {
  const StorageShrinkApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locale = ref.watch(localeProvider);
    return MaterialApp.router(
      title: 'StorageShrink',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.system,
      locale: locale,
      supportedLocales: const [Locale('en'), Locale('ar')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      routerConfig: _router,
    );
  }
}
