package com.storageshrink
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
